package com.example.esteira

import android.Manifest
import android.annotation.SuppressLint
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Acesso ao Graph: os objetos vivem no processo (mantido pelo TreadmillService), não na Activity. */
class TreadmillViewModel(app: Application) : AndroidViewModel(app) {
    init { Graph.init(app) }
    val client get() = Graph.client
    val recorder get() = Graph.recorder
    val library get() = Graph.library
    val runner get() = Graph.runner
}

class MainActivity : ComponentActivity() {

    private val vm: TreadmillViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            // Notificações são opcionais: o scan só depende das permissões de Bluetooth
            if (blePermissions().all { granted(it) }) vm.client.startScan()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { AppScreen(vm, onScan = ::requestScan) } }
    }

    private fun blePermissions() =
        if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun requestScan() {
        val perms = blePermissions().toMutableList()
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permissionLauncher.launch(perms.toTypedArray())
    }
}

@Composable
fun AppScreen(vm: TreadmillViewModel, onScan: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val view = LocalView.current
    val run by vm.runner.state.collectAsState()
    SideEffect { view.keepScreenOn = run.active }   // tela ligada durante um programa

    // Ao conectar, sobe o serviço em primeiro plano para o app continuar com a tela apagada
    val ctx = LocalContext.current
    val connected by remember { vm.client.state.map { it.connected }.distinctUntilChanged() }
        .collectAsState(initial = false)
    LaunchedEffect(connected) {
        if (connected) ContextCompat.startForegroundService(ctx, Intent(ctx, TreadmillService::class.java))
    }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Treino") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Programas") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Histórico") })
        }
        when (tab) {
            0 -> WorkoutTab(vm, onScan)
            1 -> ProgramsTab(vm, onStarted = { tab = 0 })
            else -> HistoryTab(vm.recorder)
        }
    }
}

// ---------------------------------------------------------------- Treino

@SuppressLint("MissingPermission")
@Composable
fun WorkoutTab(vm: TreadmillViewModel, onScan: () -> Unit) {
    val client = vm.client
    val s by client.state.collectAsState()
    val live by vm.recorder.live.collectAsState()
    val runState by vm.runner.state.collectAsState()
    val runActive = runState.active
    var target by remember { mutableFloatStateOf(2f) }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(s.status, style = MaterialTheme.typography.titleMedium)
        ProgramBanner(vm.runner)

        if (!s.connected) {
            Button(onClick = onScan) { Text("Procurar esteira") }
            LazyColumn {
                items(s.devices) { d ->
                    ListItem(
                        headlineContent = { Text(d.name ?: "Sem nome") },
                        supportingContent = { Text(d.address) },
                        modifier = Modifier.clickable { client.connect(d) }
                    )
                }
            }
            return@Column
        }

        val d = s.data
        Text("%.1f km/h".format(d.speedKmh), style = MaterialTheme.typography.displayLarge)
        Text(
            "FC: ${s.heartRate?.let { "$it bpm" } ?: "-- bpm"}" +
                "  •  ${d.distanceM} m  •  ${fmtTime(d.elapsedS ?: 0)}" +
                (d.kcal?.let { "  •  $it kcal" } ?: "")
        )

        LiveChart(live, maxSpeed = s.maxSpeed)

        if (!runActive) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { target = (target - 0.5f).coerceAtLeast(s.minSpeed) }) { Text("−") }
            Text("%.1f".format(target), style = MaterialTheme.typography.headlineMedium)
            OutlinedButton(onClick = { target = (target + 0.5f).coerceAtMost(s.maxSpeed) }) { Text("+") }
            Button(onClick = { client.setSpeed(target) }, enabled = s.controlGranted) { Text("Aplicar") }
        }

        if (!runActive) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { client.start() }, enabled = s.controlGranted) { Text("Iniciar") }
            OutlinedButton(onClick = { client.pause() }, enabled = s.controlGranted) { Text("Pausar") }
            OutlinedButton(onClick = { client.stop() }, enabled = s.controlGranted) { Text("Parar") }
        }

        TextButton(onClick = { client.disconnect() }) { Text("Desconectar") }
    }
}

/** Velocidade (0..maxSpeed) e FC (40..200 bpm) dos últimos 5 minutos. */
@Composable
fun LiveChart(samples: List<Sample>, maxSpeed: Float, modifier: Modifier = Modifier) {
    val speedColor = MaterialTheme.colorScheme.primary
    val hrColor = MaterialTheme.colorScheme.error
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    val win = samples.takeLast(300)

    Column(modifier) {
        Canvas(Modifier.fillMaxWidth().height(160.dp)) {
            for (i in 0..3) {
                val y = size.height * i / 3f
                drawLine(gridColor, Offset(0f, y), Offset(size.width, y))
            }
            if (win.size < 2) return@Canvas

            fun line(values: List<Float?>, min: Float, max: Float, color: Color) {
                val p = Path()
                var started = false
                values.forEachIndexed { i, v ->
                    if (v == null) return@forEachIndexed
                    val x = size.width * i / (win.size - 1)
                    val y = size.height * (1f - ((v - min) / (max - min)).coerceIn(0f, 1f))
                    if (!started) { p.moveTo(x, y); started = true } else p.lineTo(x, y)
                }
                drawPath(p, color, style = Stroke(width = 3.dp.toPx()))
            }
            line(win.map { it.speed }, 0f, maxSpeed, speedColor)
            line(win.map { it.hr?.toFloat() }, 40f, 200f, hrColor)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("— Velocidade (km/h)", color = speedColor, style = MaterialTheme.typography.labelMedium)
            Text("— FC (bpm)", color = hrColor, style = MaterialTheme.typography.labelMedium)
        }
    }
}

// ---------------------------------------------------------------- Histórico

@Composable
fun HistoryTab(recorder: WorkoutRecorder) {
    val history by recorder.history.collectAsState()
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (history.isEmpty()) {
            Text("Nenhum treino salvo ainda. O treino é gravado automaticamente quando a esteira começa a andar.")
            return@Column
        }
        Text(
            "${history.size} treinos  •  %.1f km no total".format(history.sumOf { it.distanceM } / 1000.0),
            style = MaterialTheme.typography.titleMedium
        )
        LazyColumn {
            items(history, key = { it.startMs }) { w ->
                ListItem(
                    headlineContent = { Text(fmt.format(Date(w.startMs))) },
                    supportingContent = {
                        Text(
                            "${fmtTime(w.durationS)}  •  %.2f km".format(w.distanceM / 1000.0) +
                                "  •  méd %.1f / máx %.1f km/h".format(w.avgSpeed, w.maxSpeed) +
                                (w.avgHr?.let { "  •  FC $it" } ?: "") +
                                (w.kcal?.let { "  •  $it kcal" } ?: "")
                        )
                    },
                    trailingContent = { TextButton(onClick = { recorder.delete(w) }) { Text("Excluir") } }
                )
                HorizontalDivider()
            }
        }
    }
}

fun fmtTime(totalS: Int): String {
    val h = totalS / 3600
    val m = (totalS % 3600) / 60
    val s = totalS % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}
