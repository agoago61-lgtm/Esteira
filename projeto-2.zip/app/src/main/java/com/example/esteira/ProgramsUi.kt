package com.example.esteira

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

// ---------------------------------------------------------------- Helpers

fun fmtDur(s: Int) = "%d:%02d".format(s / 60, s % 60)

/** "5" = 5 min, "1.5" = 1 min 30 s, "0:45" = 45 s, "12:30" = 12 min 30 s. */
fun parseDur(raw: String): Int? {
    val t = raw.trim().replace(',', '.')
    if (t.isEmpty()) return null
    if (':' in t) {
        val parts = t.split(':')
        val m = parts[0].toIntOrNull() ?: return null
        val s = parts.getOrNull(1)?.toIntOrNull() ?: return null
        return m * 60 + s
    }
    return t.toFloatOrNull()?.let { (it * 60).roundToInt() }
}

fun parseNum(raw: String): Float? = raw.trim().replace(',', '.').toFloatOrNull()

private data class StepDraft(val dur: String, val speed: String)

// ---------------------------------------------------------------- Banner (aba Treino)

@Composable
fun ProgramBanner(runner: ProgramRunner) {
    val r by runner.state.collectAsState()
    val p = r.program
    if (p == null) {
        r.message?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary) }
        return
    }
    val step = p.steps[r.stepIndex.coerceIn(p.steps.indices)]
    val next = p.steps.getOrNull(r.stepIndex + 1)

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(p.name, style = MaterialTheme.typography.titleSmall)
            if (r.countdownS > 0) {
                Text("Começando em ${r.countdownS}…", style = MaterialTheme.typography.headlineSmall)
            } else {
                Text("Etapa ${r.stepIndex + 1}/${p.steps.size}  •  %.1f km/h  •  restam ${fmtTime(r.stepRemainingS)}".format(step.speedKmh))
                next?.let {
                    Text(
                        "Depois: %.1f km/h por ${fmtTime(it.durationS)}".format(it.speedKmh),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                LinearProgressIndicator(
                    progress = { r.elapsedS.toFloat() / p.totalS.coerceAtLeast(1) },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("${fmtTime(r.elapsedS)} de ${fmtTime(p.totalS)}", style = MaterialTheme.typography.bodySmall)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (r.countdownS == 0) {
                    OutlinedButton(onClick = { if (r.paused) runner.resume() else runner.pause() }) {
                        Text(if (r.paused) "Retomar" else "Pausar")
                    }
                }
                OutlinedButton(onClick = { runner.stop() }) { Text("Encerrar") }
            }
        }
    }
}

// ---------------------------------------------------------------- Aba Programas

@Composable
fun ProgramsTab(vm: TreadmillViewModel, onStarted: () -> Unit) {
    val programs by vm.library.programs.collectAsState()
    val ui by vm.client.state.collectAsState()
    var editing by remember { mutableStateOf<Program?>(null) }
    var creating by remember { mutableStateOf(false) }

    if (creating || editing != null) {
        val current = editing
        ProgramEditor(
            initial = current,
            minSpeed = ui.minSpeed,
            maxSpeed = ui.maxSpeed,
            newId = { vm.library.newId() },
            onSave = { vm.library.upsert(it); editing = null; creating = false },
            onDelete = current?.let { p -> { vm.library.delete(p); editing = null; creating = false } },
            onCancel = { editing = null; creating = false }
        )
    } else {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { creating = true }) { Text("Novo programa") }
            if (!ui.connected) {
                Text(
                    "Conecte a esteira na aba Treino para poder iniciar um programa.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            LazyColumn {
                items(programs, key = { it.id }) { p ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                        Text(p.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${fmtTime(p.totalS)}  •  ${p.steps.size} etapas  •  até %.1f km/h".format(p.topSpeed) +
                                (p.goalDistanceM?.let { "  •  meta %.2f km".format(it / 1000.0) } ?: ""),
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row {
                            TextButton(onClick = { vm.runner.start(p); onStarted() }) { Text("Iniciar") }
                            TextButton(onClick = { editing = p }) { Text("Editar") }
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Editor

@Composable
fun ProgramEditor(
    initial: Program?,
    minSpeed: Float,
    maxSpeed: Float,
    newId: () -> Long,
    onSave: (Program) -> Unit,
    onDelete: (() -> Unit)?,
    onCancel: () -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "Meu programa") }
    var goal by remember { mutableStateOf(initial?.goalDistanceM?.let { "%.2f".format(it / 1000.0) } ?: "") }
    val steps = remember {
        mutableStateListOf<StepDraft>().also { l ->
            (initial?.steps ?: listOf(Step(300, 4f))).forEach {
                l.add(StepDraft(fmtDur(it.durationS), "%.1f".format(it.speedKmh)))
            }
        }
    }
    var showGen by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun save() {
        val out = ArrayList<Step>()
        steps.forEachIndexed { i, d ->
            val dur = parseDur(d.dur)
            val v = parseNum(d.speed)
            if (dur == null || dur < 5) { error = "Etapa ${i + 1}: duração inválida (mínimo 5 s)"; return }
            if (v == null || v < minSpeed || v > maxSpeed) {
                error = "Etapa ${i + 1}: velocidade entre %.1f e %.1f km/h".format(minSpeed, maxSpeed)
                return
            }
            out.add(Step(dur, v))
        }
        if (out.isEmpty()) { error = "Adicione ao menos uma etapa"; return }
        if (name.isBlank()) { error = "Dê um nome ao programa"; return }
        val g = goal.trim()
        val goalM = if (g.isEmpty()) null else parseNum(g)?.let { (it * 1000).roundToInt() }
        if (g.isNotEmpty() && (goalM == null || goalM <= 0)) { error = "Meta de distância inválida"; return }
        onSave(Program(initial?.id ?: newId(), name.trim(), out, goalM))
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedTextField(
            value = name, onValueChange = { name = it }, label = { Text("Nome") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Text("Etapas (duração em min ou mm:ss)", style = MaterialTheme.typography.titleSmall)

        steps.forEachIndexed { i, d ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${i + 1}", Modifier.width(20.dp))
                OutlinedTextField(
                    value = d.dur, onValueChange = { steps[i] = d.copy(dur = it) },
                    label = { Text("Duração") }, singleLine = true, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = d.speed, onValueChange = { steps[i] = d.copy(speed = it) },
                    label = { Text("km/h") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { steps.removeAt(i) }) { Text("X") }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { steps.add(steps.lastOrNull() ?: StepDraft("5:00", "4.0")) }) { Text("Adicionar etapa") }
            OutlinedButton(onClick = { showGen = true }) { Text("Gerar intervalado") }
        }
        Text("Duração total: ${fmtTime(steps.sumOf { parseDur(it.dur) ?: 0 })}")

        OutlinedTextField(
            value = goal, onValueChange = { goal = it },
            label = { Text("Parar ao atingir (km), opcional") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )

        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { save() }) { Text("Salvar") }
            OutlinedButton(onClick = onCancel) { Text("Cancelar") }
            onDelete?.let { TextButton(onClick = it) { Text("Excluir") } }
        }
    }

    if (showGen) {
        GeneratorDialog(
            onDismiss = { showGen = false },
            onGenerate = { list ->
                steps.clear()
                list.forEach { steps.add(StepDraft(fmtDur(it.durationS), "%.1f".format(it.speedKmh))) }
                showGen = false
            }
        )
    }
}

// ---------------------------------------------------------------- Gerador de intervalado

@Composable
private fun NumRow(l1: String, v1: String, c1: (String) -> Unit, l2: String, v2: String, c2: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = v1, onValueChange = c1, label = { Text(l1) }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f)
        )
        OutlinedTextField(
            value = v2, onValueChange = c2, label = { Text(l2) }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun GeneratorDialog(onDismiss: () -> Unit, onGenerate: (List<Step>) -> Unit) {
    var warm by remember { mutableStateOf("5") }
    var warmV by remember { mutableStateOf("5.0") }
    var reps by remember { mutableStateOf("5") }
    var workS by remember { mutableStateOf("60") }
    var workV by remember { mutableStateOf("9.0") }
    var restS by remember { mutableStateOf("120") }
    var restV by remember { mutableStateOf("6.0") }
    var cool by remember { mutableStateOf("5") }
    var coolV by remember { mutableStateOf("4.0") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Gerar intervalado") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                NumRow("Aquecimento (min)", warm, { warm = it }, "km/h", warmV, { warmV = it })
                OutlinedTextField(
                    value = reps, onValueChange = { reps = it }, label = { Text("Repetições") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()
                )
                NumRow("Tiro (s)", workS, { workS = it }, "km/h", workV, { workV = it })
                NumRow("Descanso (s)", restS, { restS = it }, "km/h", restV, { restV = it })
                NumRow("Desaquecimento (min)", cool, { cool = it }, "km/h", coolV, { coolV = it })
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val n = listOf(warm, warmV, reps, workS, workV, restS, restV, cool, coolV).map { parseNum(it) }
                if (n.any { it == null } || n[2]!! < 1f) {
                    error = "Preencha todos os campos com números"
                    return@TextButton
                }
                val v = n.map { it!! }
                onGenerate(
                    buildIntervals(
                        (v[0] * 60).roundToInt(), v[1],
                        v[2].toInt(), v[3].roundToInt(), v[4], v[5].roundToInt(), v[6],
                        (v[7] * 60).roundToInt(), v[8]
                    )
                )
            }) { Text("Gerar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
