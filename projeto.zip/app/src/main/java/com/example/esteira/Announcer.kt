package com.example.esteira

import android.content.Context
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Locale

fun spokenSpeed(v: Float): String =
    if (v % 1f == 0f) "${v.toInt()}" else "%.1f".format(v)

private fun seg(n: Int) = if (n == 1) "1 segundo" else "$n segundos"

fun spokenDur(s: Int): String {
    val m = s / 60
    val r = s % 60
    return when {
        m > 0 && r > 0 -> "$m ${if (m == 1) "minuto" else "minutos"} e ${seg(r)}"
        m > 0 -> "$m ${if (m == 1) "minuto" else "minutos"}"
        else -> seg(r)
    }
}

/** Voz em português (TextToSpeech do Android). Respeita a opção "Avisos por voz". */
class Announcer(ctx: Context, private val settings: StateFlow<AppSettings>) {
    private var tts: TextToSpeech? = null
    private var ready = false

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale.forLanguageTag("pt-BR"))
                ready = true
            }
        }
    }

    fun say(text: String) {
        if (!settings.value.voice || !ready) return
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "esteira")
    }

    fun close() {
        tts?.shutdown()
    }
}

/**
 * Treinador: anuncia cada quilômetro e avisa quando a FC sai da zona alvo.
 * Roda em segundo plano observando o estado da esteira.
 */
class Coach(
    client: TreadmillClient,
    private val settings: StateFlow<AppSettings>,
    private val announcer: Announcer
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var lastKm = 0
    private var outDir = 0
    private var outSince = 0L
    private var lastWarn = 0L

    init { scope.launch { client.state.collect { onState(it) } } }

    private fun onState(s: UiState) {
        val now = System.currentTimeMillis()
        val d = s.data
        val active = s.connected && d.speedKmh > 0.05f
        val km = d.distanceM / 1000

        if (!active) {
            lastKm = km
        } else if (km > lastKm) {
            lastKm = km
            val t = d.elapsedS?.let { " Tempo: ${spokenDur(it)}." } ?: ""
            announcer.say("$km ${if (km == 1) "quilômetro" else "quilômetros"}.$t")
        }

        val cfg = settings.value
        val hr = s.heartRate
        if (active && cfg.maxHr > 0 && cfg.targetZone > 0 && hr != null) {
            val z = hrZone(hr, cfg.maxHr)
            val dir = when {
                z > cfg.targetZone -> 1
                z < cfg.targetZone -> -1
                else -> 0
            }
            if (dir == 0) {
                outDir = 0
            } else {
                if (dir != outDir) { outDir = dir; outSince = now }
                val limit = if (dir > 0) 15_000L else 45_000L
                if (now - outSince >= limit && now - lastWarn >= 40_000L) {
                    lastWarn = now
                    announcer.say(
                        if (dir > 0) "Frequência cardíaca alta. Reduza o ritmo."
                        else "Frequência cardíaca baixa para a zona alvo."
                    )
                }
            }
        } else {
            outDir = 0
        }
    }
}
