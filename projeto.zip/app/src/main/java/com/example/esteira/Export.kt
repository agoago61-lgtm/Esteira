package com.example.esteira

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.util.Locale

/** Exportação de treinos (TCX, CSV), backup e compartilhamento. */
object Export {

    private fun f(x: Double, digits: Int = 2) = String.format(Locale.US, "%.${digits}f", x)

    /** Distância acumulada (m) em cada amostra, integrando a velocidade. */
    private fun cumulative(samples: List<Sample>): List<Double> {
        val out = ArrayList<Double>(samples.size)
        var d = 0.0
        samples.forEachIndexed { i, s ->
            if (i > 0) d += s.speed / 3.6 * (s.t - samples[i - 1].t)
            out.add(d)
        }
        return out
    }

    /** TCX: aceito por Strava, Garmin Connect e outros. */
    fun tcx(w: Workout, samples: List<Sample>): String {
        val start = Instant.ofEpochMilli(w.startMs)
        val dist = cumulative(samples)
        val scale = if (dist.isNotEmpty() && dist.last() > 0) w.distanceM / dist.last() else 1.0
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<TrainingCenterDatabase xmlns=\"http://www.garmin.com/xmlschemas/TrainingCenterDatabase/v2\" ")
        sb.append("xmlns:ns3=\"http://www.garmin.com/xmlschemas/ActivityExtension/v2\">\n")
        sb.append(" <Activities>\n")
        sb.append("  <Activity Sport=\"${if (w.avgSpeed >= 7f) "Running" else "Other"}\">\n")
        sb.append("   <Id>$start</Id>\n")
        sb.append("   <Lap StartTime=\"$start\">\n")
        sb.append("    <TotalTimeSeconds>${w.durationS}</TotalTimeSeconds>\n")
        sb.append("    <DistanceMeters>${w.distanceM}</DistanceMeters>\n")
        sb.append("    <MaximumSpeed>${f(w.maxSpeed / 3.6)}</MaximumSpeed>\n")
        sb.append("    <Calories>${w.kcal ?: 0}</Calories>\n")
        w.avgHr?.let { sb.append("    <AverageHeartRateBpm><Value>$it</Value></AverageHeartRateBpm>\n") }
        w.maxHr?.let { sb.append("    <MaximumHeartRateBpm><Value>$it</Value></MaximumHeartRateBpm>\n") }
        sb.append("    <Intensity>Active</Intensity>\n")
        sb.append("    <TriggerMethod>Manual</TriggerMethod>\n")
        sb.append("    <Track>\n")
        samples.forEachIndexed { i, s ->
            sb.append("     <Trackpoint>\n")
            sb.append("      <Time>${start.plusSeconds(s.t.toLong())}</Time>\n")
            sb.append("      <DistanceMeters>${f(dist[i] * scale)}</DistanceMeters>\n")
            s.hr?.let { sb.append("      <HeartRateBpm><Value>$it</Value></HeartRateBpm>\n") }
            sb.append("      <Extensions><ns3:TPX><ns3:Speed>${f(s.speed / 3.6)}</ns3:Speed></ns3:TPX></Extensions>\n")
            sb.append("     </Trackpoint>\n")
        }
        sb.append("    </Track>\n")
        sb.append("   </Lap>\n")
        sb.append("  </Activity>\n")
        sb.append(" </Activities>\n")
        sb.append("</TrainingCenterDatabase>\n")
        return sb.toString()
    }

    fun csv(samples: List<Sample>): String {
        val sb = StringBuilder("segundo,velocidade_kmh,fc_bpm\n")
        samples.forEach { sb.append("${it.t},${f(it.speed.toDouble())},${it.hr ?: ""}\n") }
        return sb.toString()
    }

    // ---------- Backup (programas + resumo dos treinos) ----------

    fun backupJson(programs: List<Program>, workouts: List<Workout>): String {
        val p = JSONArray()
        programs.forEach { p.put(it.toJson()) }
        val w = JSONArray()
        workouts.forEach { w.put(it.toJson()) }
        return JSONObject().put("version", 1).put("programs", p).put("workouts", w).toString(2)
    }

    fun parseBackup(text: String): Pair<List<Program>, List<Workout>>? = try {
        val o = JSONObject(text)
        val p = o.optJSONArray("programs") ?: JSONArray()
        val w = o.optJSONArray("workouts") ?: JSONArray()
        Pair(
            List(p.length()) { programFromJson(p.getJSONObject(it)) },
            List(w.length()) { workoutFromJson(w.getJSONObject(it)) }
        )
    } catch (e: Exception) { null }

    /** Aceita o texto compartilhado de um programa (extrai o JSON entre as chaves). */
    fun parseProgramText(text: String): Program? = try {
        val a = text.indexOf('{')
        val b = text.lastIndexOf('}')
        programFromJson(JSONObject(text.substring(a, b + 1)))
    } catch (e: Exception) { null }

    // ---------- Compartilhar ----------

    fun shareFile(ctx: Context, fileName: String, mime: String, content: String) {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, fileName)
        file.writeText(content)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Compartilhar").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun shareText(ctx: Context, text: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        ctx.startActivity(Intent.createChooser(send, "Compartilhar").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
