package com.example.esteira

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.Record
import androidx.health.connect.client.records.SpeedRecord
import androidx.health.connect.client.records.metadata.Device
import androidx.health.connect.client.records.metadata.Metadata
import androidx.health.connect.client.units.Energy
import androidx.health.connect.client.units.Length
import androidx.health.connect.client.units.Velocity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.Instant
import java.time.ZoneId

enum class HealthStatus { UNAVAILABLE, NEEDS_INSTALL, NEEDS_PERMISSION, READY }

/**
 * Envia os treinos ao Health Connect (Samsung Health, Google Fit e outros apps leem de lá).
 * O app só ESCREVE; não lê nenhum dado de saúde.
 */
object HealthSync {

    private const val HC_PACKAGE = "com.google.android.apps.healthdata"

    val permissions: Set<String> = setOf(
        HealthPermission.getWritePermission(ExerciseSessionRecord::class),
        HealthPermission.getWritePermission(DistanceRecord::class),
        HealthPermission.getWritePermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getWritePermission(HeartRateRecord::class),
        HealthPermission.getWritePermission(SpeedRecord::class)
    )

    private val _status = MutableStateFlow(HealthStatus.UNAVAILABLE)
    val status: StateFlow<HealthStatus> = _status.asStateFlow()

    private val _lastResult = MutableStateFlow<String?>(null)
    val lastResult: StateFlow<String?> = _lastResult.asStateFlow()

    suspend fun refresh(ctx: Context) {
        _status.value = try {
            when (HealthConnectClient.getSdkStatus(ctx, HC_PACKAGE)) {
                HealthConnectClient.SDK_AVAILABLE -> {
                    val granted = HealthConnectClient.getOrCreate(ctx).permissionController.getGrantedPermissions()
                    if (granted.containsAll(permissions)) HealthStatus.READY else HealthStatus.NEEDS_PERMISSION
                }
                HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> HealthStatus.NEEDS_INSTALL
                else -> HealthStatus.UNAVAILABLE
            }
        } catch (e: Exception) {
            HealthStatus.UNAVAILABLE
        }
    }

    /** Abre a página do Health Connect na Play Store (celulares com Android 13 ou anterior). */
    fun installIntent(): Intent = Intent(Intent.ACTION_VIEW).apply {
        setPackage("com.android.vending")
        data = Uri.parse("market://details?id=$HC_PACKAGE&url=healthconnect%3A%2F%2Fonboarding")
        putExtra("overlay", true)
        putExtra("callerId", "com.example.esteira")
    }

    /**
     * Grava o treino. O clientRecordId evita duplicar se o mesmo treino for enviado de novo.
     * [samples] alimenta as séries de velocidade e FC (vazio = só resumo).
     */
    suspend fun write(ctx: Context, w: Workout, samples: List<Sample>) {
        refresh(ctx)
        if (_status.value != HealthStatus.READY) return
        try {
            val client = HealthConnectClient.getOrCreate(ctx)
            val start = Instant.ofEpochMilli(w.startMs)
            val end = start.plusSeconds(w.durationS.toLong())
            val zs = ZoneId.systemDefault().rules.getOffset(start)
            val ze = ZoneId.systemDefault().rules.getOffset(end)
            val device = Device(type = Device.TYPE_PHONE)
            val id = "esteira-${w.startMs}"
            fun meta() = Metadata.activelyRecorded(clientRecordId = id, clientRecordVersion = 0, device = device)

            val records = mutableListOf<Record>()
            records += ExerciseSessionRecord(
                startTime = start, startZoneOffset = zs, endTime = end, endZoneOffset = ze,
                metadata = meta(),
                exerciseType = if (w.avgSpeed >= 7f) ExerciseSessionRecord.EXERCISE_TYPE_RUNNING
                               else ExerciseSessionRecord.EXERCISE_TYPE_WALKING,
                title = "Esteira"
            )
            if (w.distanceM > 0) {
                records += DistanceRecord(
                    startTime = start, startZoneOffset = zs, endTime = end, endZoneOffset = ze,
                    distance = Length.meters(w.distanceM.toDouble()), metadata = meta()
                )
            }
            w.kcal?.takeIf { it > 0 }?.let { kcal ->
                records += ActiveCaloriesBurnedRecord(
                    startTime = start, startZoneOffset = zs, endTime = end, endZoneOffset = ze,
                    energy = Energy.kilocalories(kcal.toDouble()), metadata = meta()
                )
            }

            // Reduz as séries para no máximo ~900 pontos por registro
            val inRange = samples.filter { it.t in 0..w.durationS }
            val step = ((inRange.size + 899) / 900).coerceAtLeast(1)
            val pts = inRange.filterIndexed { i, _ -> i % step == 0 }

            val hr = pts.mapNotNull { s ->
                s.hr?.let { HeartRateRecord.Sample(start.plusSeconds(s.t.toLong()), it.toLong()) }
            }
            if (hr.isNotEmpty()) {
                records += HeartRateRecord(
                    startTime = start, startZoneOffset = zs, endTime = end, endZoneOffset = ze,
                    samples = hr, metadata = meta()
                )
            }
            val sp = pts.map {
                SpeedRecord.Sample(start.plusSeconds(it.t.toLong()), Velocity.kilometersPerHour(it.speed.toDouble()))
            }
            if (sp.isNotEmpty()) {
                records += SpeedRecord(
                    startTime = start, startZoneOffset = zs, endTime = end, endZoneOffset = ze,
                    samples = sp, metadata = meta()
                )
            }

            client.insertRecords(records)
            _lastResult.value = "Treino enviado ao Health Connect"
        } catch (e: Exception) {
            _lastResult.value = "Não foi possível enviar ao Health Connect"
        }
    }
}
