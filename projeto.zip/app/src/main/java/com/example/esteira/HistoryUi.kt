package com.example.esteira

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HistoryTab(vm: TreadmillViewModel, onHealthConnect: () -> Unit, onHealthInstall: () -> Unit) {
    val recorder = vm.recorder
    val history by recorder.history.collectAsState()
    val health by HealthSync.status.collectAsState()
    val lastMsg by HealthSync.lastResult.collectAsState()
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy  HH:mm", Locale.getDefault()) }
    var selected by remember { mutableStateOf<Workout?>(null) }

    val sel = selected
    if (sel != null) {
        WorkoutDetail(vm, sel, health == HealthStatus.READY, onBack = { selected = null })
        return
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Histórico", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        HealthCard(health, lastMsg, onHealthConnect, onHealthInstall)

        if (history.isEmpty()) {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
            ) {
                Column(
                    Modifier.padding(24.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Filled.History, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.outline)
                    Text("Nenhum treino salvo ainda", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "O treino é gravado automaticamente quando a esteira começa a andar.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            history.forEach { w ->
                Card(
                    onClick = { selected = w },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(fmt.format(Date(w.startMs)), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            "${fmtTime(w.durationS)}  •  %.2f km  •  ${fmtPace(w.avgSpeed)} min/km".format(w.distanceM / 1000.0),
                            style = MaterialTheme.typography.bodyLarge
                        )
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Pill("méd %.1f km/h".format(w.avgSpeed))
                            Pill("máx %.1f km/h".format(w.maxSpeed))
                            w.avgHr?.let { Pill("FC $it") }
                            w.kcal?.let { Pill("$it kcal") }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Detalhe do treino

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WorkoutDetail(vm: TreadmillViewModel, w: Workout, hcReady: Boolean, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cfg by vm.settings.settings.collectAsState()
    val samples = remember(w.startMs) { vm.recorder.loadSamples(w.startMs) }
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy  HH:mm", Locale.getDefault()) }
    val stamp = remember { SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date(w.startMs)) }
    var confirmDelete by remember { mutableStateOf(false) }
    var sent by remember { mutableStateOf(false) }

    // Tempo em cada zona de FC (s)
    val zoneS = IntArray(6)
    if (cfg.maxHr > 0) {
        for (i in 1 until samples.size) {
            val hr = samples[i].hr ?: continue
            zoneS[hrZone(hr, cfg.maxHr)] += samples[i].t - samples[i - 1].t
        }
    }
    val zoneTotal = zoneS.sum()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.Close, contentDescription = "Voltar") }
            Text(fmt.format(Date(w.startMs)), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricTile(Icons.Filled.Timer, fmtTime(w.durationS), "duração", Modifier.weight(1f))
            MetricTile(Icons.Filled.Place, "%.2f".format(w.distanceM / 1000.0), "km", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricTile(Icons.Filled.Speed, fmtPace(w.avgSpeed), "min/km (média)", Modifier.weight(1f))
            MetricTile(Icons.Filled.Speed, "%.1f".format(w.maxSpeed), "km/h (máx)", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricTile(
                Icons.Filled.Favorite,
                if (w.avgHr != null) "${w.avgHr}" else "--",
                if (w.maxHr != null) "bpm (máx ${w.maxHr})" else "bpm (média)",
                Modifier.weight(1f)
            )
            MetricTile(Icons.Filled.LocalFireDepartment, w.kcal?.toString() ?: "--", "kcal", Modifier.weight(1f))
        }

        if (samples.size >= 2) {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Velocidade e FC", style = MaterialTheme.typography.titleSmall)
                    LiveChart(
                        samples,
                        maxSpeed = ceil(w.maxSpeed.coerceAtLeast(5f).toDouble() / 2.0).toFloat() * 2f,
                        window = samples.size
                    )
                }
            }
        }

        if (zoneTotal > 0) {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Tempo em cada zona de FC", style = MaterialTheme.typography.titleSmall)
                    for (z in 1..5) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Z$z", Modifier.width(32.dp), style = MaterialTheme.typography.labelLarge)
                            LinearProgressIndicator(
                                progress = { zoneS[z].toFloat() / zoneTotal },
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                fmtTime(zoneS[z]), Modifier.width(64.dp).padding(start = 8.dp),
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                }
            }
        }

        Text("Exportar", style = MaterialTheme.typography.titleSmall)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                Export.shareFile(ctx, "treino-$stamp.tcx", "application/xml", Export.tcx(w, samples))
            }) { Text("TCX (Strava, Garmin)") }
            OutlinedButton(onClick = {
                Export.shareFile(ctx, "treino-$stamp.csv", "text/csv", Export.csv(samples))
            }) { Text("CSV") }
            if (hcReady) {
                Button(onClick = {
                    scope.launch { HealthSync.write(ctx.applicationContext, w, samples); sent = true }
                }) { Text(if (sent) "Enviado" else "Health Connect") }
            }
        }

        TextButton(onClick = { confirmDelete = true }) {
            Text("Excluir treino", color = MaterialTheme.colorScheme.error)
        }
    }

    if (confirmDelete) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Excluir este treino?") },
            text = { Text("Isso não pode ser desfeito.") },
            confirmButton = {
                TextButton(onClick = { vm.recorder.delete(w); confirmDelete = false; onBack() }) { Text("Excluir") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun HealthCard(
    status: HealthStatus,
    lastMsg: String?,
    onConnect: () -> Unit,
    onInstall: () -> Unit
) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Favorite, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text("Health Connect", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            when (status) {
                HealthStatus.READY -> {
                    Text(
                        "Ativo. Cada treino concluído é enviado automaticamente para os seus apps de saúde.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    lastMsg?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
                HealthStatus.NEEDS_PERMISSION -> {
                    Text(
                        "Permita que o app grave seus treinos (exercício, distância, calorias, FC e velocidade) " +
                            "para ver tudo no Samsung Health, Google Fit e outros apps.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(onClick = onConnect) { Text("Permitir") }
                }
                HealthStatus.NEEDS_INSTALL -> {
                    Text(
                        "Instale ou atualize o app Health Connect para sincronizar seus treinos.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(onClick = onInstall) { Text("Abrir na Play Store") }
                }
                HealthStatus.UNAVAILABLE -> Text(
                    "O Health Connect não está disponível neste celular.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
