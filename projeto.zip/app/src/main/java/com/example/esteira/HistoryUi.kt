package com.example.esteira

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HistoryTab(recorder: WorkoutRecorder, onHealthConnect: () -> Unit, onHealthInstall: () -> Unit) {
    val history by recorder.history.collectAsState()
    val health by HealthSync.status.collectAsState()
    val lastMsg by HealthSync.lastResult.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy  HH:mm", Locale.getDefault()) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Histórico", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        HealthCard(health, lastMsg, onHealthConnect, onHealthInstall)

        if (history.isEmpty()) {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
            ) {
                Column(
                    Modifier.padding(24.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Filled.History, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.outline)
                    Text("Nenhum treino salvo ainda", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "O treino é gravado automaticamente quando a esteira começa a andar.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricTile(Icons.Filled.History, "${history.size}", "treinos", Modifier.weight(1f))
                MetricTile(
                    Icons.Filled.Place, "%.1f".format(history.sumOf { it.distanceM } / 1000.0),
                    "km no total", Modifier.weight(1f)
                )
                MetricTile(Icons.Filled.Timer, "${history.sumOf { it.durationS } / 60}", "min no total", Modifier.weight(1f))
            }

            history.forEach { w ->
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
                ) {
                    Column(Modifier.padding(start = 16.dp, top = 12.dp, end = 4.dp, bottom = 4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(fmt.format(Date(w.startMs)), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(
                                    "${fmtTime(w.durationS)}  •  %.2f km".format(w.distanceM / 1000.0),
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            }
                            IconButton(onClick = { recorder.delete(w) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Excluir treino")
                            }
                        }
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(bottom = 4.dp, end = 12.dp)
                        ) {
                            Pill("méd %.1f km/h".format(w.avgSpeed))
                            Pill("máx %.1f km/h".format(w.maxSpeed))
                            w.avgHr?.let { Pill("FC $it") }
                            w.kcal?.let { Pill("$it kcal") }
                        }
                        if (health == HealthStatus.READY) {
                            TextButton(onClick = {
                                scope.launch { HealthSync.write(ctx.applicationContext, w, emptyList()) }
                            }) { Text("Enviar ao Health Connect") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HealthCard(
    status: HealthStatus,
    lastMsg: String?,
    onConnect: () -> Unit,
    onInstall: () -> Unit
) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Favorite, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text("Health Connect", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            when (status) {
                HealthStatus.READY -> {
                    Text(
                        "Ativo. Cada treino concluído é enviado automaticamente para os seus apps de saúde.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    lastMsg?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
                HealthStatus.NEEDS_PERMISSION -> {
                    Text(
                        "Permita que o app grave seus treinos (exercício, distância, calorias, FC e velocidade) " +
                            "para ver tudo no Samsung Health, Google Fit e outros apps.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(onClick = onConnect) { Text("Permitir") }
                }
                HealthStatus.NEEDS_INSTALL -> {
                    Text(
                        "Instale ou atualize o app Health Connect para sincronizar seus treinos.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(onClick = onInstall) { Text("Abrir na Play Store") }
                }
                HealthStatus.UNAVAILABLE -> Text(
                    "O Health Connect não está disponível neste celular.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
