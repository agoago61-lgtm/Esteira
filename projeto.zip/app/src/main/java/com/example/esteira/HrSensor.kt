package com.example.esteira

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Heart Rate Measurement (0x2A37): byte 0 = flags (bit0: 0 = uint8, 1 = uint16). */
fun parseHrMeasurement(b: ByteArray?): Int? {
    if (b == null || b.size < 2) return null
    val is16 = (b[0].toInt() and 0x01) != 0
    return if (is16 && b.size >= 3) (b[1].toInt() and 0xFF) or ((b[2].toInt() and 0xFF) shl 8)
    else b[1].toInt() and 0xFF
}

data class HrSensorState(
    val scanning: Boolean = false,
    val devices: List<BluetoothDevice> = emptyList(),
    val name: String? = null,
    val connected: Boolean = false,
    val lastName: String? = null
)

/**
 * Segunda conexão Bluetooth, só para sensores de frequência cardíaca padrão (0x180D):
 * cintas peitorais e relógios que transmitem FC. A FC recebida vai para o TreadmillClient.
 */
@SuppressLint("MissingPermission")
class HrSensor(private val ctx: Context, private val client: TreadmillClient) {

    private val prefs = ctx.getSharedPreferences("esteira", Context.MODE_PRIVATE)
    private val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val handler = Handler(Looper.getMainLooper())
    private val _state = MutableStateFlow(HrSensorState(lastName = prefs.getString("hrName", null)))
    val state: StateFlow<HrSensorState> = _state.asStateFlow()

    private var gatt: BluetoothGatt? = null
    private var userStop = false

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, r: ScanResult) {
            _state.update { s ->
                if (s.devices.any { it.address == r.device.address }) s
                else s.copy(devices = s.devices + r.device)
            }
        }
    }

    fun startScan() {
        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(TreadmillClient.HR_SERVICE)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        _state.update { it.copy(scanning = true, devices = emptyList()) }
        adapter.bluetoothLeScanner.startScan(listOf(filter), settings, scanCb)
        handler.postDelayed({ stopScan() }, 15_000)
    }

    fun stopScan() {
        try { adapter.bluetoothLeScanner.stopScan(scanCb) } catch (e: Exception) { }
        _state.update { it.copy(scanning = false) }
    }

    fun connect(d: BluetoothDevice, auto: Boolean = false) {
        stopScan()
        userStop = false
        val name = d.name ?: "Sensor de FC"
        prefs.edit().putString("hrAddr", d.address).putString("hrName", name).apply()
        gatt?.close()
        gatt = d.connectGatt(ctx, auto, cb, BluetoothDevice.TRANSPORT_LE)
        _state.update { it.copy(name = name, lastName = name) }
    }

    /** Reconecta ao último sensor (fica esperando ele ligar, sem gastar bateria à toa). */
    fun reconnectLast() {
        val addr = prefs.getString("hrAddr", null) ?: return
        if (gatt != null) return
        try { connect(adapter.getRemoteDevice(addr), auto = true) } catch (e: Exception) { }
    }

    fun disconnect() {
        userStop = true
        gatt?.disconnect()
    }

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                _state.update { it.copy(connected = true) }
                g.discoverServices()
            } else {
                g.close()
                gatt = null
                client.setExternalHr(null)
                _state.update { it.copy(connected = false) }
                if (!userStop) handler.postDelayed({ reconnectLast() }, 3000)
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val c = g.getService(TreadmillClient.HR_SERVICE)
                ?.getCharacteristic(TreadmillClient.HR_MEASUREMENT) ?: return
            g.setCharacteristicNotification(c, true)
            val d = c.getDescriptor(TreadmillClient.CCCD) ?: return
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(d)
        }

        @Deprecated("Deprecated in API 33")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            parseHrMeasurement(c.value)?.let { client.setExternalHr(it) }
        }
    }
}
