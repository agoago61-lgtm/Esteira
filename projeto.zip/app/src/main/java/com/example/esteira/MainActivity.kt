package com.example.esteira

import android.Manifest
import android.annotation.SuppressLint
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.health.connect.client.PermissionController
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/** Acesso ao Graph: os objetos vivem no processo (mantido pelo TreadmillService), não na Activity. */
class TreadmillViewModel(app: Application) : AndroidViewModel(app) {
    init { Graph.init(app) }
    val client get() = Graph.client
    val recorder get() = Graph.recorder
    val library get() = Graph.library
    val runner get() = Graph.runner
}

class MainActivity : ComponentActivity() {

    private val vm: TreadmillViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            // Notificações são opcionais: o scan só depende das permissões de Bluetooth
            if (blePermissions().all { granted(it) }) vm.client.startScan()
        }

    private val healthLauncher =
        registerForActivityResult(PermissionController.createRequestPermissionResultContract()) {
            lifecycleScope.launch { HealthSync.refresh(applicationContext) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EsteiraTheme {
                AppScreen(
                    vm = vm,
                    onScan = ::requestScan,
                    onHealthConnect = { healthLauncher.launch(HealthSync.permissions) },
                    onHealthInstall = {
                        try { startActivity(HealthSync.installIntent()) } catch (e: Exception) { }
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch { HealthSync.refresh(applicationContext) }
    }

    private fun blePermissions() =
        if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun requestScan() {
        val perms = blePermissions().toMutableList()
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permissionLauncher.launch(perms.toTypedArray())
    }
}

// ---------------------------------------------------------------- Estrutura

@Composable
fun AppScreen(
    vm: TreadmillViewModel,
    onScan: () -> Unit,
    onHealthConnect: () -> Unit,
    onHealthInstall: () -> Unit
) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val view = LocalView.current
    val run by vm.runner.state.collectAsState()
    SideEffect { view.keepScreenOn = run.active }   // tela ligada durante um programa

    // Ao conectar, sobe o serviço em primeiro plano para o app continuar com a tela apagada
    val ctx = LocalContext.current
    val connected by remember { vm.client.state.map { it.connected }.distinctUntilChanged() }
        .collectAsState(initial = false)
    LaunchedEffect(connected) {
        if (connected) ContextCompat.startForegroundService(ctx, Intent(ctx, TreadmillService::class.java))
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.Speed, contentDescription = null) },
                    label = { Text("Treino") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Filled.Timer, contentDescription = null) },
                    label = { Text("Programas") }
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Filled.History, contentDescription = null) },
                    label = { Text("Histórico") }
                )
            }
        }
    ) { inner ->
        Box(Modifier.padding(inner).fillMaxSize()) {
            when (tab) {
                0 -> WorkoutTab(vm, onScan)
                1 -> ProgramsTab(vm, onStarted = { tab = 0 })
                else -> HistoryTab(vm.recorder, onHealthConnect, onHealthInstall)
            }
        }
    }
}

// ---------------------------------------------------------------- Aba Treino

@SuppressLint("MissingPermission")
@Composable
fun WorkoutTab(vm: TreadmillViewModel, onScan: () -> Unit) {
    val client = vm.client
    val s by client.state.collectAsState()
    val live by vm.recorder.live.collectAsState()
    val runState by vm.runner.state.collectAsState()
    val runActive = runState.active
    var target by remember { mutableFloatStateOf(2f) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Cabeçalho
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Esteira", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            val dot = if (s.connected) Color(0xFF2E7D32) else MaterialTheme.colorScheme.outline
            Box(Modifier.size(10.dp).background(dot, CircleShape))
            Spacer(Modifier.width(6.dp))
            Text(
                if (s.connected) "Conectada" else "Desconectada",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        ProgramBanner(vm.runner)

        if (!s.connected) {
            // ---- Conectar
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(
                    Modifier.padding(24.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        Icons.Filled.Bluetooth, contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp)
                    )
                    Text("Conecte sua esteira", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        s.status, style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Button(onClick = onScan) { Text("Procurar esteira") }
                }
            }
            if (s.devices.isNotEmpty()) {
                Text("Dispositivos encontrados", style = MaterialTheme.typography.titleSmall)
            }
            s.devices.forEach { d ->
                Card(
                    onClick = { client.connect(d) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Bluetooth, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(d.name ?: "Sem nome", style = MaterialTheme.typography.titleMedium)
                            Text(
                                d.address, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text("Conectar", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium)
                    }
                }
            }
            return@Column
        }

        // ---- Velocidade
        val d = s.data
        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        ) {
            Column(Modifier.padding(vertical = 20.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("%.1f".format(d.speedKmh), fontSize = 72.sp, fontWeight = FontWeight.Bold, lineHeight = 76.sp)
                Text("km/h", style = MaterialTheme.typography.titleMedium)
            }
        }

        // ---- Métricas
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricTile(Icons.Filled.Place, "%.2f".format(d.distanceM / 1000.0), "km", Modifier.weight(1f))
            MetricTile(Icons.Filled.Timer, fmtTime(d.elapsedS ?: 0), "tempo", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricTile(Icons.Filled.Favorite, s.heartRate?.toString() ?: "--", "bpm", Modifier.weight(1f))
            MetricTile(Icons.Filled.LocalFireDepartment, d.kcal?.toString() ?: "--", "kcal", Modifier.weight(1f))
        }

        // ---- Gráfico
        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Últimos 5 minutos", style = MaterialTheme.typography.titleSmall)
                LiveChart(live, maxSpeed = s.maxSpeed)
            }
        }

        // ---- Controles manuais (ocultos durante um programa)
        if (!runActive) {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        FilledTonalIconButton(onClick = { target = (target - 0.5f).coerceAtLeast(s.minSpeed) }) {
                            Icon(Icons.Filled.Remove, contentDescription = "Diminuir")
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("%.1f".format(target), fontSize = 36.sp, fontWeight = FontWeight.Bold)
                            Text("velocidade alvo (km/h)", style = MaterialTheme.typography.labelMedium)
                        }
                        FilledTonalIconButton(onClick = { target = (target + 0.5f).coerceAtMost(s.maxSpeed) }) {
                            Icon(Icons.Filled.Add, contentDescription = "Aumentar")
                        }
                    }
                    FilledTonalButton(
                        onClick = { client.setSpeed(target) },
                        enabled = s.controlGranted,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Aplicar velocidade") }

                    val pad = PaddingValues(horizontal = 8.dp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { client.start() }, enabled = s.controlGranted,
                            contentPadding = pad, modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.PlayArrow, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Iniciar")
                        }
                        FilledTonalButton(
                            onClick = { client.pause() }, enabled = s.controlGranted,
                            contentPadding = pad, modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Pause, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Pausar")
                        }
                        OutlinedButton(
                            onClick = { client.stop() }, enabled = s.controlGranted,
                            contentPadding = pad, modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Stop, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Parar")
                        }
                    }
                }
            }
        }

        TextButton(onClick = { client.disconnect() }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text("Desconectar")
        }
    }
}

/** Velocidade (0..maxSpeed) e FC (40..200 bpm) dos últimos 5 minutos. */
@Composable
fun LiveChart(samples: List<Sample>, maxSpeed: Float, modifier: Modifier = Modifier) {
    val speedColor = MaterialTheme.colorScheme.primary
    val hrColor = MaterialTheme.colorScheme.tertiary
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    val win = samples.takeLast(300)

    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Canvas(Modifier.fillMaxWidth().height(150.dp)) {
            for (i in 0..3) {
                val y = size.height * i / 3f
                drawLine(gridColor, androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y))
            }
            if (win.size < 2) return@Canvas

            fun series(values: List<Float?>, min: Float, max: Float, color: Color, fill: Boolean) {
                val line = Path()
                val area = Path()
                var started = false
                var lastX = 0f
                values.forEachIndexed { i, v ->
                    if (v == null) return@forEachIndexed
                    val x = size.width * i / (win.size - 1)
                    val y = size.height * (1f - ((v - min) / (max - min)).coerceIn(0f, 1f))
                    if (!started) {
                        line.moveTo(x, y); area.moveTo(x, size.height); area.lineTo(x, y); started = true
                    } else {
                        line.lineTo(x, y); area.lineTo(x, y)
                    }
                    lastX = x
                }
                if (!started) return
                if (fill) {
                    area.lineTo(lastX, size.height)
                    area.close()
                    drawPath(area, color.copy(alpha = 0.15f))
                }
                drawPath(line, color, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            series(win.map { it.speed }, 0f, maxSpeed, speedColor, fill = true)
            series(win.map { it.hr?.toFloat() }, 40f, 200f, hrColor, fill = false)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(speedColor, CircleShape)); Spacer(Modifier.width(6.dp))
                Text("Velocidade (km/h)", style = MaterialTheme.typography.labelMedium)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(hrColor, CircleShape)); Spacer(Modifier.width(6.dp))
                Text("FC (bpm)", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}
