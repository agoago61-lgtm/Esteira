package com.example.esteira

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Tela exigida pelo Health Connect: explica quais dados o app grava. */
class PrivacyActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EsteiraTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.systemBarsPadding().padding(24.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Privacidade", style = MaterialTheme.typography.headlineMedium)
                        Text(
                            "Se você permitir, o app Esteira grava no Health Connect os treinos feitos na sua esteira: " +
                                "tipo de exercício, horário, duração, distância, velocidade, calorias e frequência cardíaca."
                        )
                        Text(
                            "O app apenas grava dados; não lê nada do Health Connect. Os dados ficam no seu celular e " +
                                "não são enviados a nenhum servidor, pois o app não usa internet."
                        )
                        Text("Você pode revogar a permissão a qualquer momento nas configurações do Health Connect.")
                    }
                }
            }
        }
    }
}
