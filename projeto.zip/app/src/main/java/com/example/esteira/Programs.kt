package com.example.esteira

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Uma etapa: roda na velocidade indicada por durationS segundos. */
data class Step(val durationS: Int, val speedKmh: Float)

data class Program(
    val id: Long,
    val name: String,
    val steps: List<Step>,
    val goalDistanceM: Int? = null   // opcional: encerra ao atingir esta distância
) {
    val totalS: Int get() = steps.sumOf { it.durationS }
    val topSpeed: Float get() = steps.maxOfOrNull { it.speedKmh } ?: 0f
}

/** Aquecimento + N x (tiro + descanso) + desaquecimento. Tempo 0 = etapa omitida. */
fun buildIntervals(
    warmS: Int, warmV: Float,
    reps: Int, workS: Int, workV: Float, restS: Int, restV: Float,
    coolS: Int, coolV: Float
): List<Step> {
    val out = ArrayList<Step>()
    if (warmS > 0) out.add(Step(warmS, warmV))
    repeat(reps) {
        if (workS > 0) out.add(Step(workS, workV))
        if (restS > 0) out.add(Step(restS, restV))
    }
    if (coolS > 0) out.add(Step(coolS, coolV))
    return out
}

// ---------------------------------------------------------------- Repositório

class ProgramRepository(ctx: Context) {

    private val file = File(ctx.filesDir, "programs.json")
    private val _programs = MutableStateFlow(load())
    val programs: StateFlow<List<Program>> = _programs.asStateFlow()

    fun newId(): Long = System.currentTimeMillis()

    fun upsert(p: Program) {
        val list = _programs.value
        _programs.value =
            if (list.any { it.id == p.id }) list.map { if (it.id == p.id) p else it } else list + p
        persist()
    }

    fun delete(p: Program) {
        _programs.value = _programs.value.filter { it.id != p.id }
        persist()
    }

    private fun persist() {
        val arr = JSONArray()
        _programs.value.forEach { p ->
            val steps = JSONArray()
            p.steps.forEach { steps.put(JSONObject().put("d", it.durationS).put("v", it.speedKmh.toDouble())) }
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("goal", p.goalDistanceM)   // null remove a chave
                    .put("steps", steps)
            )
        }
        file.writeText(arr.toString())
    }

    private fun load(): List<Program> {
        if (!file.exists()) return defaults()
        return try {
            val arr = JSONArray(file.readText())
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                val st = o.getJSONArray("steps")
                Program(
                    id = o.getLong("id"),
                    name = o.getString("name"),
                    steps = List(st.length()) { j ->
                        val s = st.getJSONObject(j)
                        Step(s.getInt("d"), s.getDouble("v").toFloat())
                    },
                    goalDistanceM = if (o.has("goal")) o.getInt("goal") else null
                )
            }
        } catch (e: Exception) { defaults() }
    }

    // Exemplos para começar. Ajuste as velocidades ao seu nível.
    private fun defaults() = listOf(
        Program(1, "Caminhada leve 30 min", listOf(Step(300, 3f), Step(1200, 4.5f), Step(300, 3f))),
        Program(2, "Caminhada ritmo variável", buildIntervals(300, 3.5f, 4, 120, 5.5f, 120, 4f, 300, 3f)),
        Program(3, "Corrida intervalada 5x1", buildIntervals(300, 5f, 5, 60, 9f, 120, 6f, 300, 4f))
    )
}

// ---------------------------------------------------------------- Execução

data class RunState(
    val program: Program? = null,
    val countdownS: Int = 0,        // > 0: contagem antes de começar
    val stepIndex: Int = 0,
    val stepRemainingS: Int = 0,
    val elapsedS: Int = 0,
    val paused: Boolean = false,
    val message: String? = null     // aviso de fim ou erro
) {
    val active: Boolean get() = program != null
}

/**
 * Executa um Program: dá Start, espera a contagem da esteira, e a cada etapa
 * envia a velocidade pelo Control Point. Bipa e vibra a cada troca.
 * O app precisa ficar aberto (a tela fica ligada durante o programa).
 */
class ProgramRunner(private val ctx: Context, private val client: TreadmillClient) {

    private companion object {
        const val PRE_START_S = 4   // tempo para a esteira terminar sua contagem após o Start
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _state = MutableStateFlow(RunState())
    val state: StateFlow<RunState> = _state.asStateFlow()

    private var job: Job? = null
    private var paused = false
    private var reapply = 0
    private var tone: ToneGenerator? = null

    fun start(p: Program) {
        if (job != null || p.steps.isEmpty()) return
        val ui = client.state.value
        if (!ui.connected || !ui.controlGranted) {
            _state.value = RunState(message = "Conecte a esteira antes de iniciar o programa")
            return
        }
        paused = false
        reapply = 0
        job = scope.launch { execute(p) }
    }

    fun pause() {
        if (job == null || paused) return
        paused = true
        client.pause()
        _state.update { it.copy(paused = true) }
    }

    fun resume() {
        if (job == null || !paused) return
        paused = false
        client.start()
        reapply = PRE_START_S   // reaplica a velocidade da etapa depois da contagem da esteira
        _state.update { it.copy(paused = false) }
    }

    fun stop() {
        job?.cancel()
        finish("Programa interrompido")
    }

    fun close() {
        scope.cancel()
        tone?.release()
    }

    private suspend fun execute(p: Program) {
        client.start()
        for (c in PRE_START_S downTo 1) {
            _state.value = RunState(program = p, countdownS = c, stepRemainingS = p.steps[0].durationS)
            delay(1000)
        }
        val d0 = client.state.value.data.distanceM
        var elapsed = 0

        for ((i, step) in p.steps.withIndex()) {
            applySpeed(step.speedKmh)
            if (i > 0) alert()
            var rem = step.durationS
            while (rem > 0) {
                _state.value = RunState(
                    program = p, stepIndex = i, stepRemainingS = rem,
                    elapsedS = elapsed, paused = paused
                )
                delay(1000)
                if (!client.state.value.connected) {
                    finish("Conexão perdida. Programa encerrado", stopMachine = false)
                    return
                }
                if (reapply > 0) {
                    reapply--
                    if (reapply == 0) applySpeed(step.speedKmh)
                    continue
                }
                if (paused) continue
                rem--
                elapsed++
                if (rem in 1..3) beep(120)
                val goal = p.goalDistanceM
                if (goal != null && client.state.value.data.distanceM - d0 >= goal) {
                    finish("Meta de distância atingida")
                    return
                }
            }
        }
        finish("Programa concluído")
    }

    private fun applySpeed(v: Float) {
        val ui = client.state.value
        client.setSpeed(v.coerceIn(ui.minSpeed, ui.maxSpeed))
    }

    private fun finish(msg: String, stopMachine: Boolean = true) {
        if (stopMachine) {
            client.stop()
            alert()
        }
        job = null
        paused = false
        reapply = 0
        _state.value = RunState(message = msg)
    }

    private fun beep(ms: Int) {
        try {
            if (tone == null) tone = ToneGenerator(AudioManager.STREAM_MUSIC, 90)
            tone?.startTone(ToneGenerator.TONE_PROP_BEEP, ms)
        } catch (e: Exception) { }
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        try {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            v?.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) { }
    }

    private fun alert() { beep(400); buzz() }
}
