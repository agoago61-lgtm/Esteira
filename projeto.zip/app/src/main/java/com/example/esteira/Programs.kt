package com.example.esteira

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs

/** Uma etapa: roda na velocidade indicada por durationS segundos. */
data class Step(val durationS: Int, val speedKmh: Float)

data class Program(
    val id: Long,
    val name: String,
    val steps: List<Step>,
    val goalDistanceM: Int? = null,   // opcional: encerra ao atingir esta distância
    val goalKcal: Int? = null         // opcional: encerra ao atingir estas calorias
) {
    val totalS: Int get() = steps.sumOf { it.durationS }
    val topSpeed: Float get() = steps.maxOfOrNull { it.speedKmh } ?: 0f
    /** Programa "sem fim" (treino com meta de distância ou calorias). */
    val isOpenEnded: Boolean get() = totalS >= 6 * 3600
}

/** Aquecimento + N x (tiro + descanso) + desaquecimento. Tempo 0 = etapa omitida. */
fun buildIntervals(
    warmS: Int, warmV: Float,
    reps: Int, workS: Int, workV: Float, restS: Int, restV: Float,
    coolS: Int, coolV: Float
): List<Step> {
    val out = ArrayList<Step>()
    if (warmS > 0) out.add(Step(warmS, warmV))
    repeat(reps) {
        if (workS > 0) out.add(Step(workS, workV))
        if (restS > 0) out.add(Step(restS, restV))
    }
    if (coolS > 0) out.add(Step(coolS, coolV))
    return out
}

/** Plano "do sofá aos 5 km": 8 semanas, cada uma é um programa (repita 3x na semana). */
fun couchTo5k(baseId: Long): List<Program> {
    // (corrida em s, caminhada em s, repetições)
    val weeks = listOf(
        Triple(60, 90, 8), Triple(90, 90, 7), Triple(120, 90, 6), Triple(180, 90, 5),
        Triple(300, 120, 4), Triple(480, 120, 3), Triple(720, 120, 2), Triple(1500, 0, 1)
    )
    return weeks.mapIndexed { i, (jog, walk, reps) ->
        Program(
            baseId + i, "Iniciante 5 km • semana ${i + 1}",
            buildIntervals(300, 4f, reps, jog, 7f, walk, 4.5f, 300, 4f)
        )
    }
}

// ---------------------------------------------------------------- JSON

fun Program.toJson(): JSONObject {
    val arr = JSONArray()
    steps.forEach { arr.put(JSONObject().put("d", it.durationS).put("v", it.speedKmh.toDouble())) }
    return JSONObject()
        .put("id", id)
        .put("name", name)
        .put("goal", goalDistanceM)   // null remove a chave
        .put("kcal", goalKcal)
        .put("steps", arr)
}

fun programFromJson(o: JSONObject): Program {
    val st = o.getJSONArray("steps")
    return Program(
        id = o.getLong("id"),
        name = o.getString("name"),
        steps = List(st.length()) { j ->
            val s = st.getJSONObject(j)
            Step(s.getInt("d"), s.getDouble("v").toFloat())
        },
        goalDistanceM = if (o.has("goal")) o.getInt("goal") else null,
        goalKcal = if (o.has("kcal")) o.getInt("kcal") else null
    )
}

// ---------------------------------------------------------------- Repositório

class ProgramRepository(ctx: Context) {

    private val file = File(ctx.filesDir, "programs.json")
    private val _programs = MutableStateFlow(load())
    val programs: StateFlow<List<Program>> = _programs.asStateFlow()

    fun newId(): Long = System.currentTimeMillis()

    fun upsert(p: Program) {
        val list = _programs.value
        _programs.value =
            if (list.any { it.id == p.id }) list.map { if (it.id == p.id) p else it } else list + p
        persist()
    }

    fun upsertAll(list: List<Program>) {
        list.forEach { p ->
            val cur = _programs.value
            _programs.value =
                if (cur.any { it.id == p.id }) cur.map { if (it.id == p.id) p else it } else cur + p
        }
        persist()
    }

    fun delete(p: Program) {
        _programs.value = _programs.value.filter { it.id != p.id }
        persist()
    }

    private fun persist() {
        val arr = JSONArray()
        _programs.value.forEach { arr.put(it.toJson()) }
        file.writeText(arr.toString())
    }

    private fun load(): List<Program> {
        if (!file.exists()) return defaults()
        return try {
            val arr = JSONArray(file.readText())
            List(arr.length()) { programFromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) { defaults() }
    }

    // Exemplos para começar. Ajuste as velocidades ao seu nível.
    private fun defaults() = listOf(
        Program(1, "Caminhada leve 30 min", listOf(Step(300, 3f), Step(1200, 4.5f), Step(300, 3f))),
        Program(2, "Caminhada ritmo variável", buildIntervals(300, 3.5f, 4, 120, 5.5f, 120, 4f, 300, 3f)),
        Program(3, "Corrida intervalada 5x1", buildIntervals(300, 5f, 5, 60, 9f, 120, 6f, 300, 4f))
    )
}

// ---------------------------------------------------------------- Execução

data class RunState(
    val program: Program? = null,
    val countdownS: Int = 0,        // > 0: contagem antes de começar
    val stepIndex: Int = 0,
    val stepRemainingS: Int = 0,
    val elapsedS: Int = 0,
    val paused: Boolean = false,
    val message: String? = null     // aviso de fim ou erro
) {
    val active: Boolean get() = program != null
}

/**
 * Executa um Program: dá Start, espera a contagem da esteira, e a cada etapa
 * envia a velocidade pelo Control Point. Bipa, vibra e fala a cada troca.
 * Se a conexão cair, espera até LOST_LIMIT_S segundos pela reconexão automática.
 */
class ProgramRunner(
    private val ctx: Context,
    private val client: TreadmillClient,
    private val say: (String) -> Unit,
    private val settings: StateFlow<AppSettings>
) {

    private companion object {
        const val PRE_START_S = 4     // tempo para a esteira terminar sua contagem após o Start
        const val LOST_LIMIT_S = 20   // quanto esperar pela reconexão antes de encerrar
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _state = MutableStateFlow(RunState())
    val state: StateFlow<RunState> = _state.asStateFlow()

    private var job: Job? = null
    private var paused = false
    private var reapply = 0
    private var lostS = 0
    private var cmdSpeed = 0f     // última velocidade enviada à esteira
    private var desired = 0f      // velocidade da etapa atual
    private var tone: ToneGenerator? = null

    fun start(p: Program) {
        if (job != null || p.steps.isEmpty()) return
        val ui = client.state.value
        if (!ui.connected || !ui.controlGranted) {
            _state.value = RunState(message = "Conecte a esteira antes de iniciar o programa")
            return
        }
        paused = false
        reapply = 0
        lostS = 0
        job = scope.launch { execute(p) }
    }

    fun pause() {
        if (job == null || paused) return
        paused = true
        client.pause()
        _state.update { it.copy(paused = true) }
    }

    fun resume() {
        if (job == null || !paused) return
        paused = false
        client.start()
        reapply = PRE_START_S   // reaplica a velocidade da etapa depois da contagem da esteira
        _state.update { it.copy(paused = false) }
    }

    fun stop() {
        job?.cancel()
        finish("Programa interrompido")
    }

    fun close() {
        scope.cancel()
        tone?.release()
    }

    private suspend fun execute(p: Program) {
        client.start()
        say("Iniciando ${p.name}")
        for (c in PRE_START_S downTo 1) {
            _state.value = RunState(program = p, countdownS = c, stepRemainingS = p.steps[0].durationS)
            delay(1000)
        }
        val d0 = client.state.value.data.distanceM
        val k0 = client.state.value.data.kcal ?: 0
        var elapsed = 0

        for ((i, step) in p.steps.withIndex()) {
            desired = step.speedKmh
            if (i == 0 || !settings.value.smooth) {
                applySpeed(desired)
                cmdSpeed = desired
            } else {
                rampTick()
            }
            if (i > 0) alert()
            say(
                (if (i == 0) "Primeira etapa" else "Próxima etapa") +
                    ": ${spokenSpeed(step.speedKmh)} quilômetros por hora" +
                    (if (p.isOpenEnded) "" else ", por ${spokenDur(step.durationS)}")
            )

            var rem = step.durationS
            while (rem > 0) {
                _state.value = RunState(
                    program = p, stepIndex = i, stepRemainingS = rem,
                    elapsedS = elapsed, paused = paused
                )
                delay(1000)
                val ui = client.state.value

                // Conexão caiu: não conta tempo enquanto a reconexão automática tenta
                if (!ui.connected) {
                    lostS++
                    if (lostS == 1) { alert(); say("Conexão perdida com a esteira") }
                    if (lostS >= LOST_LIMIT_S) {
                        finish("Conexão perdida. Verifique a esteira.", stopMachine = false)
                        return
                    }
                    continue
                }
                if (lostS > 0) {
                    lostS = 0
                    say("Conexão restabelecida")
                    client.start()
                    reapply = 3
                }

                if (reapply > 0) {
                    if (ui.controlGranted) reapply--
                    if (reapply == 0) { applySpeed(desired); cmdSpeed = desired }
                    continue
                }
                if (paused) continue

                if (settings.value.smooth) rampTick()
                rem--
                elapsed++
                if (rem == 10 && step.durationS > 25 && !p.isOpenEnded) say("Faltam 10 segundos")
                if (rem in 1..3 && !p.isOpenEnded) beep(120)

                val goalM = p.goalDistanceM
                if (goalM != null && ui.data.distanceM - d0 >= goalM) {
                    finish("Meta de distância atingida")
                    return
                }
                val goalK = p.goalKcal
                if (goalK != null && (ui.data.kcal ?: 0) - k0 >= goalK) {
                    finish("Meta de calorias atingida")
                    return
                }
            }
        }
        finish("Programa concluído")
    }

    /** Sobe ou desce no máximo 0,5 km/h por segundo até a velocidade da etapa. */
    private fun rampTick() {
        val diff = desired - cmdSpeed
        if (abs(diff) < 0.01f) return
        val next = if (abs(diff) <= 0.5f) desired else cmdSpeed + (if (diff > 0) 0.5f else -0.5f)
        cmdSpeed = next
        applySpeed(next)
    }

    private fun applySpeed(v: Float) {
        val ui = client.state.value
        client.setSpeed(v.coerceIn(ui.minSpeed, ui.maxSpeed))
    }

    private fun finish(msg: String, stopMachine: Boolean = true) {
        if (stopMachine) {
            client.stop()
            alert()
        }
        say(msg)
        job = null
        paused = false
        reapply = 0
        lostS = 0
        _state.value = RunState(message = msg)
    }

    private fun beep(ms: Int) {
        try {
            if (tone == null) tone = ToneGenerator(AudioManager.STREAM_MUSIC, 90)
            tone?.startTone(ToneGenerator.TONE_PROP_BEEP, ms)
        } catch (e: Exception) { }
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        try {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            v?.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) { }
    }

    private fun alert() { beep(400); buzz() }
}
