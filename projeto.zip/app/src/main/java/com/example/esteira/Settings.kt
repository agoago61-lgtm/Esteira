package com.example.esteira

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    val age: Int = 0,
    val weightKg: Float = 0f,
    val weeklyGoalKm: Float = 0f,
    val targetZone: Int = 0,          // 0 = sem alerta; 1..5 = zona alvo de FC
    val voice: Boolean = true,
    val smooth: Boolean = true,       // transição suave entre etapas
    val reminderOn: Boolean = false,
    val reminderHour: Int = 18,
    val maxSpeed: Float = 0f,         // limite manual de velocidade (0 = o da esteira)
    val inclineDeg: Float = 0f        // inclinação fixa da esteira, em graus (para as calorias)
) {
    /** FC máxima estimada (220 - idade). 0 = idade não informada. */
    val maxHr: Int get() = if (age in 10..100) 220 - age else 0
}

val ZONE_NAMES = listOf("", "Muito leve", "Leve", "Moderada", "Intensa", "Máxima")

/** Zona 1..5 pela % da FC máxima (<60, 60-70, 70-80, 80-90, 90+). 0 = sem FC máxima. */
fun hrZone(hr: Int, maxHr: Int): Int {
    if (maxHr <= 0) return 0
    val pct = hr * 100f / maxHr
    return when {
        pct < 60f -> 1
        pct < 70f -> 2
        pct < 80f -> 3
        pct < 90f -> 4
        else -> 5
    }
}

class SettingsRepo(ctx: Context) {
    private val p = ctx.getSharedPreferences("esteira", Context.MODE_PRIVATE)
    private val _s = MutableStateFlow(load())
    val settings: StateFlow<AppSettings> = _s.asStateFlow()

    fun update(f: (AppSettings) -> AppSettings) {
        _s.value = f(_s.value)
        save(_s.value)
    }

    private fun load() = AppSettings(
        age = p.getInt("age", 0),
        weightKg = p.getFloat("weight", 0f),
        weeklyGoalKm = p.getFloat("goal", 0f),
        targetZone = p.getInt("zone", 0),
        voice = p.getBoolean("voice", true),
        smooth = p.getBoolean("smooth", true),
        reminderOn = p.getBoolean("remOn", false),
        reminderHour = p.getInt("remHour", 18),
        maxSpeed = p.getFloat("maxSpeed", 0f),
        inclineDeg = p.getFloat("incline", 0f)
    )

    private fun save(s: AppSettings) {
        p.edit()
            .putInt("age", s.age)
            .putFloat("weight", s.weightKg)
            .putFloat("goal", s.weeklyGoalKm)
            .putInt("zone", s.targetZone)
            .putBoolean("voice", s.voice)
            .putBoolean("smooth", s.smooth)
            .putBoolean("remOn", s.reminderOn)
            .putInt("remHour", s.reminderHour)
            .putFloat("maxSpeed", s.maxSpeed)
            .putFloat("incline", s.inclineDeg)
            .apply()
    }
}
