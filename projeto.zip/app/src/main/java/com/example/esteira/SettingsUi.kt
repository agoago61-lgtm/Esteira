package com.example.esteira

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
private fun SwitchRow(title: String, desc: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsTab(vm: TreadmillViewModel, onExport: () -> Unit, onImport: () -> Unit) {
    val repo = vm.settings
    val cfg by repo.settings.collectAsState()
    val ctx = LocalContext.current
    val diag by vm.client.diag.collectAsState()

    var age by remember { mutableStateOf(if (cfg.age > 0) cfg.age.toString() else "") }
    var weight by remember { mutableStateOf(if (cfg.weightKg > 0f) "%.1f".format(cfg.weightKg) else "") }
    var goal by remember { mutableStateOf(if (cfg.weeklyGoalKm > 0f) "%.1f".format(cfg.weeklyGoalKm) else "") }
    var incl by remember { mutableStateOf(if (cfg.inclineDeg > 0f) "%.1f".format(cfg.inclineDeg) else "") }
    var maxSp by remember { mutableStateOf(if (cfg.maxSpeed > 0f) "%.1f".format(cfg.maxSpeed) else "") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Ajustes", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        SectionCard("Perfil") {
            OutlinedTextField(
                value = age, singleLine = true, label = { Text("Idade") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                onValueChange = { v ->
                    age = v
                    repo.update { it.copy(age = v.trim().toIntOrNull() ?: 0) }
                },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = weight, singleLine = true, label = { Text("Peso (kg)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                onValueChange = { v ->
                    weight = v
                    repo.update { it.copy(weightKg = parseNum(v) ?: 0f) }
                },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = goal, singleLine = true, label = { Text("Meta semanal (km)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                onValueChange = { v ->
                    goal = v
                    repo.update { it.copy(weeklyGoalKm = parseNum(v) ?: 0f) }
                },
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "A idade define sua FC máxima (220 − idade). Com o peso informado, as calorias do treino " +
                    "são calculadas pelo app (calorias ativas, acima do repouso) em vez de usar o valor da esteira.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        SectionCard("Esteira") {
            OutlinedTextField(
                value = maxSp, singleLine = true, label = { Text("Velocidade máxima (km/h)") },
                placeholder = { Text("automática") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                onValueChange = { v ->
                    maxSp = v
                    repo.update { it.copy(maxSpeed = parseNum(v)?.takeIf { x -> x > 0f } ?: 0f) }
                },
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Limite usado nos programas e nos controles. Deixe vazio para usar o valor informado pela esteira " +
                    "(última leitura: %.1f km/h). Se o app limitar abaixo do que a sua esteira faz, digite aqui a velocidade máxima, por exemplo 12.".format(vm.client.detectedMax),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedTextField(
                value = incl, singleLine = true, label = { Text("Inclinação fixa (graus)") },
                placeholder = { Text("0") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                onValueChange = { v ->
                    incl = v
                    repo.update { it.copy(inclineDeg = parseNum(v)?.coerceIn(0f, 30f) ?: 0f) }
                },
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Para esteiras com inclinação manual (pezinho). Usada só no cálculo das calorias, que exige o peso no Perfil. " +
                    "Não muda a distância nem o ritmo.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        SectionCard("Zona de FC alvo") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = cfg.targetZone == 0,
                    onClick = { repo.update { it.copy(targetZone = 0) } },
                    label = { Text("Desligado") }
                )
                for (z in 1..5) {
                    FilterChip(
                        selected = cfg.targetZone == z,
                        onClick = { repo.update { it.copy(targetZone = z) } },
                        label = { Text("Z$z") }
                    )
                }
            }
            if (cfg.maxHr > 0) {
                val m = cfg.maxHr
                val lim = listOf(0, 60, 70, 80, 90, 100)
                for (z in 1..5) {
                    val lo = m * lim[z - 1] / 100
                    val hi = m * lim[z] / 100
                    Text(
                        "Z$z ${ZONE_NAMES[z]}: " + (if (z == 1) "até $hi" else "$lo a $hi") + " bpm",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Text(
                    "Com uma zona escolhida, o app avisa por voz se a FC ficar acima ou abaixo dela.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Text(
                    "Informe a idade no Perfil para calcular as zonas.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        SectionCard("Voz e programas") {
            SwitchRow(
                "Avisos por voz",
                "Anuncia etapas, quilômetros e alertas de FC.",
                cfg.voice
            ) { on -> repo.update { it.copy(voice = on) } }
            SwitchRow(
                "Transição suave",
                "Sobe ou desce a velocidade em degraus de 0,5 km/h entre etapas.",
                cfg.smooth
            ) { on -> repo.update { it.copy(smooth = on) } }
        }

        SectionCard("Lembrete diário") {
            SwitchRow(
                "Lembrar de treinar",
                "Avisa quanto falta para a meta da semana. Não avisa se a meta já foi batida.",
                cfg.reminderOn
            ) { on ->
                repo.update { it.copy(reminderOn = on) }
                if (on) Reminder.schedule(ctx, cfg.reminderHour) else Reminder.cancel(ctx)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FilledTonalIconButton(onClick = {
                    val h = (cfg.reminderHour + 23) % 24
                    repo.update { it.copy(reminderHour = h) }
                    if (cfg.reminderOn) Reminder.schedule(ctx, h)
                }) { Icon(Icons.Filled.Remove, contentDescription = "Mais cedo") }
                Text("%02d:00".format(cfg.reminderHour), style = MaterialTheme.typography.titleLarge)
                FilledTonalIconButton(onClick = {
                    val h = (cfg.reminderHour + 1) % 24
                    repo.update { it.copy(reminderHour = h) }
                    if (cfg.reminderOn) Reminder.schedule(ctx, h)
                }) { Icon(Icons.Filled.Add, contentDescription = "Mais tarde") }
            }
        }

        SectionCard("Diagnóstico da esteira") {
            Text(
                "Últimos pacotes recebidos da esteira. Se alguma leitura parecer errada, conecte, deixe a esteira andando e envie um print desta tela.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (diag.isEmpty()) {
                Text("Nenhum pacote recebido ainda.", style = MaterialTheme.typography.bodySmall)
            } else {
                diag.forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
            }
        }

        SectionCard("Backup") {
            Text(
                "Salva seus programas e o resumo dos treinos em um arquivo, para guardar ou levar a outro celular.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onExport) { Text("Exportar") }
                OutlinedButton(onClick = onImport) { Text("Importar") }
            }
        }
    }
}
