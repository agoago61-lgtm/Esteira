package com.example.esteira

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------------------------------------------------------------- Cálculos

/** Início da semana atual (segunda-feira, 00:00). */
fun weekStartMs(now: Long = System.currentTimeMillis()): Long {
    val c = Calendar.getInstance().apply {
        firstDayOfWeek = Calendar.MONDAY
        timeInMillis = now
        set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    return c.timeInMillis
}

fun weekKm(h: List<Workout>): Float {
    val start = weekStartMs()
    return h.filter { it.startMs >= start }.sumOf { it.distanceM } / 1000f
}

/** Km por semana, da mais antiga para a atual. */
fun weeklyKm(h: List<Workout>, weeks: Int = 8): List<Float> {
    val start = weekStartMs()
    return (weeks - 1 downTo 0).map { i ->
        val c = Calendar.getInstance().apply {
            firstDayOfWeek = Calendar.MONDAY
            timeInMillis = start
            add(Calendar.WEEK_OF_YEAR, -i)
        }
        val a = c.timeInMillis
        c.add(Calendar.WEEK_OF_YEAR, 1)
        val b = c.timeInMillis
        h.filter { it.startMs in a until b }.sumOf { it.distanceM } / 1000f
    }
}

private fun dayKey(ms: Long): Int {
    val c = Calendar.getInstance().apply { timeInMillis = ms }
    return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
}

/** Dias seguidos com treino (conta a partir de hoje, ou de ontem se hoje ainda não treinou). */
fun streakDays(h: List<Workout>): Int {
    val days = h.map { dayKey(it.startMs) }.toSet()
    val c = Calendar.getInstance()
    if (dayKey(c.timeInMillis) !in days) c.add(Calendar.DAY_OF_YEAR, -1)
    var n = 0
    while (dayKey(c.timeInMillis) in days) {
        n++
        c.add(Calendar.DAY_OF_YEAR, -1)
    }
    return n
}

// ---------------------------------------------------------------- Aba Evolução

@Composable
fun StatsTab(vm: TreadmillViewModel) {
    val history by vm.recorder.history.collectAsState()
    val cfg by vm.settings.settings.collectAsState()
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }
    val week = weekKm(history)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Evolução", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Meta da semana", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (cfg.weeklyGoalKm > 0f) {
                    LinearProgressIndicator(
                        progress = { (week / cfg.weeklyGoalKm).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(10.dp)
                    )
                    Text(
                        "%.1f de %.1f km".format(week, cfg.weeklyGoalKm) +
                            if (week >= cfg.weeklyGoalKm) "  •  meta batida!" else "",
                        style = MaterialTheme.typography.bodyLarge
                    )
                } else {
                    Text("%.1f km nesta semana. Defina uma meta semanal em Ajustes.".format(week))
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricTile(Icons.Filled.Star, "${streakDays(history)}", "dias seguidos", Modifier.weight(1f))
            MetricTile(Icons.Filled.History, "${history.size}", "treinos", Modifier.weight(1f))
            MetricTile(
                Icons.Filled.Place, "%.0f".format(history.sumOf { it.distanceM } / 1000.0),
                "km no total", Modifier.weight(1f)
            )
        }

        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Quilômetros por semana", style = MaterialTheme.typography.titleSmall)
                WeeklyBars(weeklyKm(history))
                Text(
                    "As 8 últimas semanas; a barra forte é a atual.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Recordes", style = MaterialTheme.typography.titleSmall)
                if (history.isEmpty()) {
                    Text("Seus recordes aparecem depois do primeiro treino.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    history.maxByOrNull { it.distanceM }?.let {
                        Text("Maior distância: %.2f km  •  ${fmt.format(Date(it.startMs))}".format(it.distanceM / 1000.0))
                    }
                    history.maxByOrNull { it.durationS }?.let {
                        Text("Maior duração: ${fmtTime(it.durationS)}  •  ${fmt.format(Date(it.startMs))}")
                    }
                    history.filter { it.durationS >= 600 }.maxByOrNull { it.avgSpeed }?.let {
                        Text("Melhor ritmo (10 min ou mais): ${fmtPace(it.avgSpeed)} min/km  •  ${fmt.format(Date(it.startMs))}")
                    }
                }
            }
        }
    }
}

@Composable
fun WeeklyBars(values: List<Float>) {
    val strong = MaterialTheme.colorScheme.primary
    val soft = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
    val top = (values.maxOrNull() ?: 1f).coerceAtLeast(1f)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Canvas(Modifier.fillMaxWidth().height(120.dp)) {
            val n = values.size
            val slot = size.width / n
            values.forEachIndexed { i, v ->
                val h = (size.height * (v / top)).coerceAtLeast(4f)
                drawRoundRect(
                    color = if (i == n - 1) strong else soft,
                    topLeft = Offset(i * slot + slot * 0.15f, size.height - h),
                    size = Size(slot * 0.7f, h),
                    cornerRadius = CornerRadius(8f, 8f)
                )
            }
        }
        Row(Modifier.fillMaxWidth()) {
            values.forEach { v ->
                Text(
                    "%.0f".format(v), Modifier.weight(1f), textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}
