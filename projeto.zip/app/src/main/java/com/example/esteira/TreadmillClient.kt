package com.example.esteira

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.ParcelUuid
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.roundToInt

data class TreadmillData(
    val speedKmh: Float = 0f,
    val distanceM: Int = 0,
    val inclinationPct: Float? = null,
    val elapsedS: Int? = null,
    val heartRate: Int? = null,
    val kcal: Int? = null
)

data class UiState(
    val status: String = "Desconectado",
    val devices: List<BluetoothDevice> = emptyList(),
    val connected: Boolean = false,
    val controlGranted: Boolean = false,
    val data: TreadmillData = TreadmillData(),
    val minSpeed: Float = 1f,
    val maxSpeed: Float = 10f,
    val hr: Int? = null,           // FC vinda do serviço Heart Rate (0x180D) da própria esteira
    val extHr: Int? = null         // FC de um sensor externo (cinta, relógio)
) {
    /** FC efetiva: sensor externo, depois serviço 0x180D da esteira, depois Treadmill Data. 0 = sem leitura. */
    val heartRate: Int? get() = (extHr ?: hr ?: data.heartRate)?.takeIf { it > 0 }
}

/**
 * Cliente FTMS (Fitness Machine Service 0x1826).
 * Esteira testada via nRF Connect: expõe 0x2ACD (Treadmill Data),
 * 0x2AD9 (Control Point), 0x2AD4 (Supported Speed Range) e 0x2ADA (Machine Status).
 */
@SuppressLint("MissingPermission")
class TreadmillClient(private val ctx: Context) {

    companion object {
        private fun u(short: Int) = UUID.fromString(String.format("%08x-0000-1000-8000-00805f9b34fb", short))
        val FTMS: UUID = u(0x1826)
        val TREADMILL_DATA: UUID = u(0x2ACD)
        val CONTROL_POINT: UUID = u(0x2AD9)
        val SPEED_RANGE: UUID = u(0x2AD4)
        val MACHINE_STATUS: UUID = u(0x2ADA)
        val HR_SERVICE: UUID = u(0x180D)
        val HR_MEASUREMENT: UUID = u(0x2A37)
        val CCCD: UUID = u(0x2902)
    }

    private val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var gatt: BluetoothGatt? = null
    private var controlChar: BluetoothGattCharacteristic? = null

    private val prefs = ctx.getSharedPreferences("esteira", Context.MODE_PRIVATE)
    private var userDisconnect = false
    private val lastAddress: String? get() = prefs.getString("lastAddr", null)
    val lastDeviceName: String? get() = prefs.getString("lastName", null)
    fun hasLastDevice() = lastAddress != null

    fun setExternalHr(v: Int?) { _state.update { it.copy(extHr = v) } }

    // Diagnóstico: últimos pacotes brutos do Treadmill Data (aba Ajustes)
    private val _diag = MutableStateFlow<List<String>>(emptyList())
    val diag: StateFlow<List<String>> = _diag.asStateFlow()
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    private fun logPacket(b: ByteArray) {
        val flags = if (b.size >= 2) (b[0].toInt() and 0xFF) or ((b[1].toInt() and 0xFF) shl 8) else 0
        val line = "${clock.format(Date())} f=0x%04X ".format(flags) + b.joinToString(" ") { "%02X".format(it) }
        _diag.update { (listOf(line) + it).take(8) }
    }

    // Faixa de velocidade: a informada pela esteira (guardada para uso sem conexão) e um limite manual
    private var reportedMin = prefs.getFloat("rangeMin", 1f)
    private var reportedMax = prefs.getFloat("rangeMax", 12f)
    private var overrideMax = 0f
    val detectedMax: Float get() = reportedMax

    init { applyRange() }

    private fun applyRange() {
        _state.update {
            it.copy(minSpeed = reportedMin, maxSpeed = if (overrideMax > 0f) overrideMax else reportedMax)
        }
    }

    /** Limite máximo definido pelo usuário em Ajustes (0 = usar o da esteira). */
    fun setMaxOverride(v: Float) {
        overrideMax = v
        applyRange()
    }

    // O Android só aceita uma operação GATT por vez: serializamos numa fila.
    private val queue = ArrayDeque<() -> Boolean>()
    private var busy = false

    @Synchronized private fun enqueue(op: () -> Boolean) {
        queue.addLast(op)
        if (!busy) pump()
    }

    @Synchronized private fun pump() {
        busy = false
        while (queue.isNotEmpty()) {
            if (queue.removeFirst().invoke()) { busy = true; return }
        }
    }

    @Synchronized private fun resetQueue() { queue.clear(); busy = false }

    // ---------- Scan / conexão ----------

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, r: ScanResult) {
            _state.update { s ->
                if (s.devices.any { it.address == r.device.address }) s
                else s.copy(devices = s.devices + r.device)
            }
        }
    }

    fun startScan() {
        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(FTMS)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        _state.update { it.copy(devices = emptyList(), status = "Procurando esteira…") }
        adapter.bluetoothLeScanner.startScan(listOf(filter), settings, scanCb)
    }

    fun stopScan() = adapter.bluetoothLeScanner.stopScan(scanCb)

    fun connect(device: BluetoothDevice) {
        stopScan()
        userDisconnect = false
        prefs.edit().putString("lastAddr", device.address).putString("lastName", device.name ?: "Esteira").apply()
        _state.update { it.copy(status = "Conectando…") }
        gatt?.close()
        gatt = device.connectGatt(ctx, false, gattCb, BluetoothDevice.TRANSPORT_LE)
    }

    /** Reconecta à última esteira. Fica esperando ela ligar (autoConnect). */
    fun reconnectLast() {
        val addr = lastAddress ?: return
        if (gatt != null) return
        try {
            userDisconnect = false
            _state.update { it.copy(status = "Reconectando…") }
            gatt = adapter.getRemoteDevice(addr).connectGatt(ctx, true, gattCb, BluetoothDevice.TRANSPORT_LE)
        } catch (e: Exception) {
            _state.update { it.copy(status = "Desconectado") }
        }
    }

    fun disconnect() {
        userDisconnect = true
        gatt?.disconnect()
    }

    // ---------- GATT ----------

    private val gattCb = object : BluetoothGattCallback() {

        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.discoverServices()
            } else {
                val byUser = userDisconnect
                g.close(); gatt = null; controlChar = null; resetQueue()
                _state.update { UiState(status = "Desconectado", extHr = it.extHr, minSpeed = it.minSpeed, maxSpeed = it.maxSpeed) }
                userDisconnect = false
                if (!byUser && lastAddress != null) reconnectLast()
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val ftms = g.getService(FTMS)
            if (ftms == null) {
                _state.update { it.copy(status = "Serviço FTMS não encontrado") }
                return
            }
            controlChar = ftms.getCharacteristic(CONTROL_POINT)

            enqueue { g.readCharacteristic(ftms.getCharacteristic(SPEED_RANGE)) }
            enqueue { subscribe(g, ftms.getCharacteristic(CONTROL_POINT), indicate = true) }
            enqueue { subscribe(g, ftms.getCharacteristic(TREADMILL_DATA), indicate = false) }
            enqueue { subscribe(g, ftms.getCharacteristic(MACHINE_STATUS), indicate = false) }
            g.getService(HR_SERVICE)?.let { hr ->
                enqueue { subscribe(g, hr.getCharacteristic(HR_MEASUREMENT), indicate = false) }
            }
            send(byteArrayOf(0x00)) // Request Control
            _state.update { it.copy(connected = true, status = "Conectado") }
        }

        @Deprecated("Deprecated in API 33")
        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            if (c.uuid == SPEED_RANGE && c.value != null && c.value.size >= 4) {
                val b = c.value
                val min = ((b[0].toInt() and 0xFF) or ((b[1].toInt() and 0xFF) shl 8)) / 100f
                val max = ((b[2].toInt() and 0xFF) or ((b[3].toInt() and 0xFF) shl 8)) / 100f
                reportedMin = min
                reportedMax = max
                prefs.edit().putFloat("rangeMin", min).putFloat("rangeMax", max).apply()
                applyRange()
            }
            pump()
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) = pump()
        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) = pump()

        @Deprecated("Deprecated in API 33")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val b = c.value ?: return
            when (c.uuid) {
                TREADMILL_DATA -> {
                    logPacket(b)
                    // Pacotes parciais (FTMS "More Data") só trazem alguns campos: mescla com o último valor
                    _state.update { s ->
                        val d = parseTreadmillData(b, s.data)
                        if (d != null) s.copy(data = d) else s
                    }
                }
                HR_MEASUREMENT -> parseHeartRate(b)?.let { v -> _state.update { it.copy(hr = v) } }
                CONTROL_POINT -> {
                    // Resposta: [0x80, opcode requisitado, resultado (0x01 = sucesso)]
                    if (b.size >= 3 && b[0] == 0x80.toByte()) {
                        val ok = b[2] == 0x01.toByte()
                        if (b[1] == 0x00.toByte()) _state.update { it.copy(controlGranted = ok) }
                        if (!ok) _state.update { it.copy(status = "Comando 0x%02X recusado (código %d)".format(b[1], b[2])) }
                    }
                }
            }
        }
    }

    private fun subscribe(g: BluetoothGatt, c: BluetoothGattCharacteristic?, indicate: Boolean): Boolean {
        c ?: return false
        g.setCharacteristicNotification(c, true)
        val d = c.getDescriptor(CCCD) ?: return false
        d.value = if (indicate) BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                  else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
        return g.writeDescriptor(d)
    }

    // ---------- Parser do Treadmill Data (0x2ACD) ----------

    private fun parseTreadmillData(b: ByteArray, prev: TreadmillData): TreadmillData? = try {
        var i = 0
        fun u8() = b[i++].toInt() and 0xFF
        fun u16() = u8() or (u8() shl 8)
        fun s16() = u16().toShort().toInt()
        fun u24() = u8() or (u8() shl 8) or (u8() shl 16)

        val flags = u16()
        var d = prev
        if ((flags and 0x001) == 0) d = d.copy(speedKmh = u16() / 100f)        // velocidade instantânea
        if ((flags and 0x002) != 0) i += 2                                      // velocidade média
        if ((flags and 0x004) != 0) d = d.copy(distanceM = u24())               // distância total (m)
        if ((flags and 0x008) != 0) { d = d.copy(inclinationPct = s16() / 10f); i += 2 } // inclinação + ramp angle
        if ((flags and 0x010) != 0) i += 4                                      // ganho de elevação
        if ((flags and 0x020) != 0) i += 1                                      // pace instantâneo
        if ((flags and 0x040) != 0) i += 1                                      // pace médio
        if ((flags and 0x080) != 0) { d = d.copy(kcal = u16()); i += 3 }       // energia (total, /h, /min)
        if ((flags and 0x100) != 0) d = d.copy(heartRate = u8())               // frequência cardíaca
        if ((flags and 0x200) != 0) i += 1                                      // MET
        if ((flags and 0x400) != 0) d = d.copy(elapsedS = u16())               // tempo decorrido (s)
        d
    } catch (e: IndexOutOfBoundsException) { null }

    // Heart Rate Measurement: byte 0 = flags (bit0: 0 = uint8, 1 = uint16), depois o valor
    private fun parseHeartRate(b: ByteArray): Int? {
        if (b.size < 2) return null
        val is16 = (b[0].toInt() and 0x01) != 0
        return if (is16 && b.size >= 3) (b[1].toInt() and 0xFF) or ((b[2].toInt() and 0xFF) shl 8)
        else b[1].toInt() and 0xFF
    }

    // ---------- Comandos (Control Point 0x2AD9) ----------

    private fun send(bytes: ByteArray) = enqueue {
        val c = controlChar ?: return@enqueue false
        c.value = bytes
        gatt?.writeCharacteristic(c) ?: false
    }

    fun start() = send(byteArrayOf(0x07))
    fun pause() = send(byteArrayOf(0x08, 0x02))
    fun stop() = send(byteArrayOf(0x08, 0x01))

    fun setSpeed(kmh: Float) {
        val v = (kmh * 100).roundToInt()
        send(byteArrayOf(0x02, (v and 0xFF).toByte(), ((v shr 8) and 0xFF).toByte()))
    }
}
