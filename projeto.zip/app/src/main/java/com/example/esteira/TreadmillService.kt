package com.example.esteira

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

/**
 * Objetos que precisam sobreviver à Activity: conexão BLE, gravador, programas e execução.
 * Vivem enquanto o processo existir; o TreadmillService mantém o processo vivo em 2º plano.
 */
object Graph {
    lateinit var client: TreadmillClient; private set
    lateinit var recorder: WorkoutRecorder; private set
    lateinit var library: ProgramRepository; private set
    lateinit var runner: ProgramRunner; private set
    private var ready = false
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Synchronized
    fun init(ctx: Context) {
        if (ready) return
        val app = ctx.applicationContext
        client = TreadmillClient(app)
        recorder = WorkoutRecorder(app, client.state)
        library = ProgramRepository(app)
        runner = ProgramRunner(app, client)
        // Ao terminar um treino, envia ao Health Connect (se o usuário permitiu)
        recorder.onFinished = { w, samples -> ioScope.launch { HealthSync.write(app, w, samples) } }
        ready = true
    }
}

/**
 * Serviço em primeiro plano (tipo connectedDevice): mostra uma notificação fixa e
 * segura um wake lock parcial para a CPU não dormir no meio do programa.
 * Para sozinho quando a esteira desconecta e nenhum programa está rodando.
 */
class TreadmillService : Service() {

    private companion object {
        const val CHANNEL = "esteira"
        const val ID = 1
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wake: PowerManager.WakeLock? = null
    private var started = false
    private var lastText = "Esteira conectada"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Esteira", NotificationManager.IMPORTANCE_LOW)
        )
        val n = build(lastText)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(ID, n)
        }
        if (!started) {
            started = true
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "esteira:service")
                .apply { acquire(4 * 60 * 60 * 1000L) }   // solta sozinho após 4 h

            scope.launch {
                combine(Graph.client.state, Graph.runner.state) { ui, run ->
                    val p = run.program
                    when {
                        !ui.connected && !run.active -> null
                        p != null && run.countdownS == 0 ->
                            "${p.name} • etapa ${run.stepIndex + 1}/${p.steps.size} • " +
                                "%.1f km/h".format(p.steps[run.stepIndex.coerceIn(p.steps.indices)].speedKmh)
                        else -> "Esteira conectada • %.1f km/h".format(ui.data.speedKmh)
                    }
                }.distinctUntilChanged().collect { text ->
                    if (text == null) {
                        stopSelf()
                    } else {
                        lastText = text
                        nm.notify(ID, build(text))
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun build(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("Esteira")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        wake?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
