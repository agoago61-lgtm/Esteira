package com.example.esteira

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

// ---------------------------------------------------------------- Tema

private val LightColors = lightColorScheme(
    primary = Color(0xFFD32F2F), onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDAD6), onPrimaryContainer = Color(0xFF410002),
    secondary = Color(0xFF775652), onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFDAD6), onSecondaryContainer = Color(0xFF2C1512),
    tertiary = Color(0xFF1565C0), onTertiary = Color.White,
    background = Color(0xFFFFFBFF), onBackground = Color(0xFF201A19),
    surface = Color(0xFFFFFBFF), onSurface = Color(0xFF201A19),
    surfaceVariant = Color(0xFFF5DDDA), onSurfaceVariant = Color(0xFF534341),
    outline = Color(0xFF857371), outlineVariant = Color(0xFFD8C2BF),
    error = Color(0xFFBA1A1A), onError = Color.White,
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFFFF0EE),
    surfaceContainer = Color(0xFFFAEAE7),
    surfaceContainerHigh = Color(0xFFF4E4E1),
    surfaceContainerHighest = Color(0xFFEEDEDB)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFF6659), onPrimary = Color(0xFF3A0003),
    primaryContainer = Color(0xFF93000A), onPrimaryContainer = Color(0xFFFFDAD6),
    secondary = Color(0xFFE7BDB7), onSecondary = Color(0xFF442926),
    secondaryContainer = Color(0xFF5D3F3B), onSecondaryContainer = Color(0xFFFFDAD6),
    tertiary = Color(0xFF90CAF9), onTertiary = Color(0xFF003258),
    background = Color(0xFF1A1110), onBackground = Color(0xFFF1DFDC),
    surface = Color(0xFF1A1110), onSurface = Color(0xFFF1DFDC),
    surfaceVariant = Color(0xFF534341), onSurfaceVariant = Color(0xFFD8C2BF),
    outline = Color(0xFFA08C8A), outlineVariant = Color(0xFF534341),
    error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
    surfaceContainerLowest = Color(0xFF140C0B),
    surfaceContainerLow = Color(0xFF231918),
    surfaceContainer = Color(0xFF271D1C),
    surfaceContainerHigh = Color(0xFF322826),
    surfaceContainerHighest = Color(0xFF3D3231)
)

/** Segue o tema do sistema (claro/escuro). Vermelho como cor principal. */
@Composable
fun EsteiraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}

// ---------------------------------------------------------------- Componentes

fun fmtTime(totalS: Int): String {
    val h = totalS / 3600
    val m = (totalS % 3600) / 60
    val s = totalS % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

@Composable
fun MetricTile(icon: ImageVector, value: String, unit: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(unit, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun Pill(text: String) {
    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
        Text(
            text,
            Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelMedium
        )
    }
}

/** Miniatura do programa: largura = duração, altura = velocidade de cada etapa. */
@Composable
fun StepsPreview(steps: List<Step>, modifier: Modifier = Modifier) {
    val color = MaterialTheme.colorScheme.primary
    val total = steps.sumOf { it.durationS }.coerceAtLeast(1)
    val top = (steps.maxOfOrNull { it.speedKmh } ?: 1f).coerceAtLeast(1f)
    Canvas(modifier.fillMaxWidth().height(44.dp)) {
        var x = 0f
        steps.forEach { s ->
            val w = size.width * s.durationS / total
            val ratio = (s.speedKmh / top).coerceIn(0.15f, 1f)
            val h = size.height * ratio
            drawRoundRect(
                color = color.copy(alpha = 0.4f + 0.6f * ratio),
                topLeft = Offset(x + 1f, size.height - h),
                size = Size((w - 2f).coerceAtLeast(1f), h),
                cornerRadius = CornerRadius(6f, 6f)
            )
            x += w
        }
    }
}

/** Ritmo em min/km a partir da velocidade em km/h. */
fun fmtPace(speedKmh: Float): String {
    if (speedKmh < 0.5f) return "--:--"
    val sec = (3600f / speedKmh).roundToInt()
    return "%d:%02d".format(sec / 60, sec % 60)
}
