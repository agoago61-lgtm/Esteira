package com.example.esteira

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Uma amostra por segundo, usada no gráfico ao vivo. */
data class Sample(val t: Int, val speed: Float, val hr: Int?)

data class Workout(
    val startMs: Long,
    val durationS: Int,
    val distanceM: Int,
    val avgSpeed: Float,
    val maxSpeed: Float,
    val avgHr: Int?,
    val kcal: Int?
)

/**
 * Observa o estado da esteira e grava um treino automaticamente:
 * começa quando a velocidade passa de 0 e termina após 10 s parada (ou ao desconectar).
 * Treinos com menos de 30 s são descartados.
 *
 * Limitação: o treino em andamento vive só na memória. Se o Android matar o app
 * no meio da corrida, esse treino se perde (para evitar, use um foreground service).
 */
class WorkoutRecorder(ctx: Context, state: StateFlow<UiState>) {

    private val file = File(ctx.filesDir, "workouts.json")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _live = MutableStateFlow<List<Sample>>(emptyList())
    val live: StateFlow<List<Sample>> = _live.asStateFlow()

    private val _history = MutableStateFlow(load())
    val history: StateFlow<List<Workout>> = _history.asStateFlow()

    private companion object {
        const val IDLE_MS = 10_000L
        const val MIN_DURATION_S = 30
    }

    // Estado do treino em andamento (acessado só pelo coletor, em uma única coroutine)
    private var started = false
    private var startMs = 0L
    private var lastMs = 0L
    private var lastActiveMs = 0L
    private var lastSampleMs = 0L
    private var lastSpeed = 0f
    private var distM = 0.0
    private var kcalFirst: Int? = null
    private var kcalLast: Int? = null
    private val buf = ArrayList<Sample>()

    init { scope.launch { state.collect { onState(it) } } }

    fun close() = scope.cancel()

    private fun onState(s: UiState) {
        val now = System.currentTimeMillis()
        val speed = s.data.speedKmh
        val active = s.connected && speed > 0.05f

        if (!started) {
            if (!active) return
            started = true
            startMs = now; lastMs = now; lastActiveMs = now; lastSampleMs = 0L
            lastSpeed = speed; distM = 0.0
            kcalFirst = s.data.kcal; kcalLast = s.data.kcal
            buf.clear()
        }

        // Integra a distância pela velocidade (independe do contador da esteira)
        distM += lastSpeed / 3.6 * (now - lastMs) / 1000.0
        lastSpeed = speed
        lastMs = now
        if (active) lastActiveMs = now
        s.data.kcal?.let { kcalLast = it }

        if (!s.connected || now - lastActiveMs > IDLE_MS) {
            finish()
            return
        }

        if (now - lastSampleMs >= 1000) {
            lastSampleMs = now
            buf.add(Sample(((now - startMs) / 1000).toInt(), speed, s.heartRate))
            _live.value = buf.toList()
        }
    }

    private fun finish() {
        val durationS = ((lastActiveMs - startMs) / 1000).toInt()
        if (durationS >= MIN_DURATION_S) {
            val hrs = buf.mapNotNull { it.hr }
            val k0 = kcalFirst
            val k1 = kcalLast
            val w = Workout(
                startMs = startMs,
                durationS = durationS,
                distanceM = distM.toInt(),
                avgSpeed = (distM / durationS * 3.6).toFloat(),
                maxSpeed = buf.maxOfOrNull { it.speed } ?: 0f,
                avgHr = if (hrs.isEmpty()) null else hrs.average().toInt(),
                kcal = if (k0 != null && k1 != null) (k1 - k0).coerceAtLeast(0) else null
            )
            _history.value = listOf(w) + _history.value
            persist()
        }
        started = false
        buf.clear()
        _live.value = emptyList()
    }

    fun delete(w: Workout) {
        _history.value = _history.value.filter { it.startMs != w.startMs }
        persist()
    }

    // ---------- Persistência (JSON em filesDir) ----------

    private fun persist() {
        val arr = JSONArray()
        _history.value.forEach { w ->
            arr.put(
                JSONObject()
                    .put("startMs", w.startMs)
                    .put("durationS", w.durationS)
                    .put("distanceM", w.distanceM)
                    .put("avgSpeed", w.avgSpeed.toDouble())
                    .put("maxSpeed", w.maxSpeed.toDouble())
                    .put("avgHr", w.avgHr)   // null remove a chave
                    .put("kcal", w.kcal)
            )
        }
        file.writeText(arr.toString())
    }

    private fun load(): List<Workout> = try {
        val arr = JSONArray(file.readText())
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Workout(
                startMs = o.getLong("startMs"),
                durationS = o.getInt("durationS"),
                distanceM = o.getInt("distanceM"),
                avgSpeed = o.getDouble("avgSpeed").toFloat(),
                maxSpeed = o.getDouble("maxSpeed").toFloat(),
                avgHr = if (o.has("avgHr")) o.getInt("avgHr") else null,
                kcal = if (o.has("kcal")) o.getInt("kcal") else null
            )
        }
    } catch (e: Exception) { emptyList() }
}
