package com.example.esteira

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.tan

/** Uma amostra por segundo, usada nos gráficos. */
data class Sample(val t: Int, val speed: Float, val hr: Int?)

data class Workout(
    val startMs: Long,
    val durationS: Int,
    val distanceM: Int,
    val avgSpeed: Float,
    val maxSpeed: Float,
    val avgHr: Int?,
    val kcal: Int?,
    val maxHr: Int? = null
)

fun Workout.toJson(): JSONObject = JSONObject()
    .put("startMs", startMs)
    .put("durationS", durationS)
    .put("distanceM", distanceM)
    .put("avgSpeed", avgSpeed.toDouble())
    .put("maxSpeed", maxSpeed.toDouble())
    .put("avgHr", avgHr)     // null remove a chave
    .put("kcal", kcal)
    .put("maxHr", maxHr)

fun workoutFromJson(o: JSONObject) = Workout(
    startMs = o.getLong("startMs"),
    durationS = o.getInt("durationS"),
    distanceM = o.getInt("distanceM"),
    avgSpeed = o.getDouble("avgSpeed").toFloat(),
    maxSpeed = o.getDouble("maxSpeed").toFloat(),
    avgHr = if (o.has("avgHr")) o.getInt("avgHr") else null,
    kcal = if (o.has("kcal")) o.getInt("kcal") else null,
    maxHr = if (o.has("maxHr")) o.getInt("maxHr") else null
)

fun loadWorkouts(ctx: Context): List<Workout> = try {
    val arr = JSONArray(File(ctx.filesDir, "workouts.json").readText())
    List(arr.length()) { workoutFromJson(arr.getJSONObject(it)) }
} catch (e: Exception) { emptyList() }

/**
 * Calorias ativas (acima do repouso) pela equação da ACSM para esteira, sem inclinação:
 * caminhada até 6 km/h: 0,1 ml/kg/min por m/min (+1,8 por inclinação); acima disso, corrida: 0,2 (+0,9).
 */
fun estimateKcal(samples: List<Sample>, weightKg: Float, inclineDeg: Float = 0f): Int {
    if (weightKg <= 0f || samples.size < 2) return 0
    val grade = tan(inclineDeg * PI / 180.0).coerceIn(0.0, 0.4)   // inclinação como fração (0,2 = 20%)
    var kcal = 0.0
    for (i in 1 until samples.size) {
        val dtMin = (samples[i].t - samples[i - 1].t).coerceIn(0, 5) / 60.0
        val v = samples[i].speed
        if (v < 0.5f) continue
        val mPerMin = v * 1000.0 / 60.0
        val netVo2 = if (v <= 6.0f) 0.1 * mPerMin + 1.8 * mPerMin * grade else 0.2 * mPerMin + 0.9 * mPerMin * grade
        kcal += netVo2 * weightKg / 1000.0 * 5.0 * dtMin
    }
    return kcal.roundToInt()
}

/**
 * Observa o estado da esteira e grava um treino automaticamente:
 * começa quando a velocidade passa de 0 e termina após 10 s parada.
 * Treinos com menos de 30 s são descartados. Uma queda de conexão curta
 * (menos de 10 s) não divide o treino em dois.
 *
 * Limitação: o treino em andamento vive só na memória. Se o Android matar o app
 * no meio da corrida, esse treino se perde.
 */
class WorkoutRecorder(
    private val ctx: Context,
    state: StateFlow<UiState>,
    private val settings: StateFlow<AppSettings>
) {

    private val file = File(ctx.filesDir, "workouts.json")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _live = MutableStateFlow<List<Sample>>(emptyList())
    val live: StateFlow<List<Sample>> = _live.asStateFlow()

    private val _history = MutableStateFlow(loadWorkouts(ctx))
    val history: StateFlow<List<Workout>> = _history.asStateFlow()

    /** Chamado quando um treino termina e é salvo (usado para enviar ao Health Connect). */
    var onFinished: ((Workout, List<Sample>) -> Unit)? = null

    private companion object {
        const val IDLE_MS = 10_000L
        const val MIN_DURATION_S = 30
    }

    private var started = false
    private var startMs = 0L
    private var lastMs = 0L
    private var lastActiveMs = 0L
    private var lastSampleMs = 0L
    private var lastSpeed = 0f
    private var distM = 0.0
    private var distFirst = 0
    private var distLast = 0
    private var kcalFirst: Int? = null
    private var kcalLast: Int? = null
    private val buf = ArrayList<Sample>()

    // Lê o estado a cada segundo (a esteira só notifica quando algo muda, e o tempo não pode depender disso)
    init {
        scope.launch {
            while (true) {
                delay(1000)
                onState(state.value)
            }
        }
    }

    fun close() = scope.cancel()

    private fun onState(s: UiState) {
        val now = System.currentTimeMillis()
        val speed = s.data.speedKmh
        val active = speed > 0.05f

        if (!started) {
            if (!active) return
            started = true
            startMs = now; lastMs = now; lastActiveMs = now; lastSampleMs = 0L
            lastSpeed = speed; distM = 0.0
            kcalFirst = s.data.kcal; kcalLast = s.data.kcal
            distFirst = s.data.distanceM; distLast = s.data.distanceM
            buf.clear()
        }

        distM += lastSpeed / 3.6 * (now - lastMs) / 1000.0
        lastSpeed = speed
        lastMs = now
        if (active) lastActiveMs = now
        s.data.kcal?.let { kcalLast = it }
        if (s.data.distanceM > 0) distLast = s.data.distanceM

        if (now - lastActiveMs > IDLE_MS) {
            finish()
            return
        }

        if (now - lastSampleMs >= 900) {
            lastSampleMs = now
            buf.add(Sample(((now - startMs) / 1000).toInt(), speed, s.heartRate))
            _live.value = buf.toList()
        }
    }

    private fun finish() {
        val durationS = ((lastActiveMs - startMs) / 1000).toInt()
        if (durationS >= MIN_DURATION_S) {
            val full = buf.filter { it.t <= durationS }
            val hrs = full.mapNotNull { it.hr }
            val k0 = kcalFirst
            val k1 = kcalLast
            val weight = settings.value.weightKg
            // Distância: integral da velocidade; se der quase zero, usa o contador da esteira
            val machineM = (distLast - distFirst).coerceAtLeast(0)
            val dist = if (distM >= 10.0 || machineM == 0) distM.toInt() else machineM
            val kcal = when {
                weight > 0f -> estimateKcal(full, weight, settings.value.inclineDeg)   // cálculo do app (peso e inclinação)
                k0 != null && k1 != null -> (k1 - k0).coerceAtLeast(0)
                else -> null
            }
            val w = Workout(
                startMs = startMs,
                durationS = durationS,
                distanceM = dist,
                avgSpeed = (dist.toDouble() / durationS * 3.6).toFloat(),
                maxSpeed = full.maxOfOrNull { it.speed } ?: 0f,
                avgHr = if (hrs.isEmpty()) null else hrs.average().toInt(),
                kcal = kcal,
                maxHr = hrs.maxOrNull()
            )
            _history.value = listOf(w) + _history.value
            persist()
            saveSamples(w.startMs, full)
            onFinished?.invoke(w, full)
        }
        started = false
        buf.clear()
        _live.value = emptyList()
    }

    fun delete(w: Workout) {
        _history.value = _history.value.filter { it.startMs != w.startMs }
        persist()
        samplesFile(w.startMs).delete()
    }

    /** Junta treinos de um backup (sem duplicar pelo horário de início). */
    fun importWorkouts(list: List<Workout>) {
        val known = _history.value.map { it.startMs }.toSet()
        val added = list.filter { it.startMs !in known }
        _history.value = (_history.value + added).sortedByDescending { it.startMs }
        persist()
    }

    private fun persist() {
        val arr = JSONArray()
        _history.value.forEach { arr.put(it.toJson()) }
        file.writeText(arr.toString())
    }

    // ---------- Amostras de cada treino (gráfico do detalhe, exportação) ----------

    private fun samplesFile(startMs: Long) = File(ctx.filesDir, "samples_$startMs.csv")

    private fun saveSamples(startMs: Long, list: List<Sample>) {
        try {
            val step = (list.size / 900).coerceAtLeast(1)   // até ~900 pontos
            samplesFile(startMs).writeText(
                list.filterIndexed { i, _ -> i % step == 0 }.joinToString("\n") {
                    "${it.t},${"%.2f".format(Locale.US, it.speed)},${it.hr ?: ""}"
                }
            )
        } catch (e: Exception) { }
    }

    fun loadSamples(startMs: Long): List<Sample> = try {
        samplesFile(startMs).readLines().mapNotNull { line ->
            val p = line.split(",")
            if (p.size < 2) null else Sample(p[0].toInt(), p[1].toFloat(), p.getOrNull(2)?.toIntOrNull())
        }
    } catch (e: Exception) { emptyList() }
}
